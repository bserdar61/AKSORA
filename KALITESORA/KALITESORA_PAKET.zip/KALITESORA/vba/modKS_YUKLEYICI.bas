Attribute VB_Name = "modKS_YUKLEYICI"
Option Explicit

' Tek mod�l i�e aktar�l�r, gerisini bu y�kleyici yapar:
'   1) Se�ilen klas�rdeki t�m modKS_*.bas mod�llerini i�e aktar�r (varsa eskisini de�i�tirir).
'   2) ThisWorkbook'a a��l�� kodunu (Workbook_Open -> KS_ACILIS) ekler.
'   3) KALITESORA_KUR kurulumunu ba�lat�r.
' Gerekli ayar: Dosya > Se�enekler > G�ven Merkezi > G�ven Merkezi Ayarlar� > Makro Ayarlar� >
'               "VBA proje nesne modeline eri�ime g�ven" i�aretli olmal�.

Public Sub KALITESORA_YUKLE()
    Dim proje As Object, bilesen As Object, klasor As String, f As String, ad As String, adet As Long
    Dim cm As Object, sep As String, adim As String, dlg As Object, metin As String
    On Error GoTo Hata

    adim = "VBA projesine eri�im"
    Set proje = ThisWorkbook.VBProject
    adet = proje.VBComponents.Count
    adet = 0

    adim = "Klas�r se�imi"
    sep = Application.PathSeparator
    Set dlg = Application.FileDialog(4)   ' msoFileDialogFolderPicker
    dlg.Title = "KAL�TESORA .bas dosyalar�n�n bulundu�u klas�r� se�in"
    If Len(ThisWorkbook.Path) > 0 Then dlg.InitialFileName = ThisWorkbook.Path & sep
    If dlg.Show <> -1 Then Exit Sub
    klasor = dlg.SelectedItems(1)
    If Right$(klasor, 1) = sep Then klasor = Left$(klasor, Len(klasor) - 1)
    If Len(Dir$(klasor & sep & "modKS_CEKIRDEK.bas")) = 0 Then
        MsgBox "Se�ilen klas�rde modKS_CEKIRDEK.bas bulunamad�." & vbCrLf & klasor, vbExclamation, "KAL�TESORA"
        Exit Sub
    End If

    f = Dir$(klasor & sep & "modKS_*.bas")
    Do While Len(f) > 0
        ad = Left$(f, Len(f) - 4)
        If StrComp(ad, "modKS_YUKLEYICI", vbTextCompare) <> 0 Then
            adim = "��e aktarma: " & f
            Set bilesen = Nothing
            On Error Resume Next
            Set bilesen = proje.VBComponents(ad)
            On Error GoTo Hata
            If Not bilesen Is Nothing Then proje.VBComponents.Remove bilesen
            proje.VBComponents.Import klasor & sep & f
            adet = adet + 1
        End If
        f = Dir$()
    Loop

    adim = "ThisWorkbook a��l�� kodu"
    Set cm = proje.VBComponents(ThisWorkbook.CodeName).CodeModule
    If cm.CountOfLines > 0 Then metin = cm.Lines(1, cm.CountOfLines)
    If InStr(1, metin, "KS_ACILIS", vbTextCompare) = 0 Then
        If InStr(1, metin, "Workbook_Open", vbTextCompare) > 0 Then
            MsgBox "ThisWorkbook i�inde ba�ka bir Workbook_Open var; a��l�� kodu eklenmedi." & vbCrLf & _
                "��ine elle 'KS_ACILIS' sat�r�n� ekleyin.", vbExclamation, "KAL�TESORA"
        Else
            cm.AddFromString "Private Sub Workbook_Open()" & vbCrLf & _
                "    KS_ACILIS" & vbCrLf & "End Sub"
        End If
    End If
    If InStr(1, metin, "KS_DEGISIKLIK", vbTextCompare) = 0 Then
        cm.AddFromString "Private Sub Workbook_SheetChange(ByVal Sh As Object, ByVal Target As Range)" & vbCrLf & _
            "    KS_DEGISIKLIK Sh, Target" & vbCrLf & "End Sub"
    End If

    MsgBox adet & " mod�l i�e aktar�ld�. �imdi kurulum ba�layacak.", vbInformation, "KAL�TESORA"
    Application.Run "'" & ThisWorkbook.Name & "'!KALITESORA_KUR"
    Exit Sub
Hata:
    MsgBox "Y�kleme durdu." & vbCrLf & "Ad�m: " & adim & vbCrLf & "Hata: " & Err.Description & vbCrLf & vbCrLf & _
        "VBA eri�im hatas�ysa: Dosya > Se�enekler > G�ven Merkezi > G�ven Merkezi Ayarlar� > Makro Ayarlar� > " & _
        "'VBA proje nesne modeline eri�ime g�ven' kutusunu i�aretleyin.", vbExclamation, "KAL�TESORA"
End Sub
