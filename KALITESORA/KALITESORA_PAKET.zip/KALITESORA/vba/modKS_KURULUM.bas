Attribute VB_Name = "modKS_KURULUM"
Option Explicit

' KAL�TESORA kurulumu. Bo� bir .xlsm dosyas�nda t�m sayfalar�, tablolar�, formu ve paneli olu�turur.
' Tekrar �al��t�r�ld���nda veri tablolar�na dokunmaz; yaln�z eksikleri tamamlar ve tasar�m� yeniler.

Private Const ETIKET As String = "_KS_KURULU"

Public Function KS_Kurulu() As Boolean
    KS_Kurulu = KS_AdVar(ETIKET)
End Function

Public Sub KALITESORA_KUR()
    Dim adim As String, yedek As String, ilk As Boolean, ad As Variant, ws As Worksheet
    Dim onceki As Long, gorselYok As Boolean
    On Error GoTo Hata

    If Len(ThisWorkbook.Path) = 0 Or LCase$(Right$(ThisWorkbook.Name, 5)) <> ".xlsm" Then
        MsgBox "�nce dosyay� 'Makro ��erebilen Excel �al��ma Kitab� (.xlsm)' olarak kaydedin, " & _
            "sonra kurulumu �al��t�r�n.", vbExclamation, KS_AD
        Exit Sub
    End If
    If ThisWorkbook.ReadOnly Then
        MsgBox "Dosya salt okunur a��k. Yaz�labilir kopyada �al��t�r�n.", vbExclamation, KS_AD
        Exit Sub
    End If
    gorselYok = (Len(KS_GorselYol("KALITESORA_BANNER.png")) = 0)

    ilk = Not KS_Kurulu()
    If ilk Then
        If MsgBox(KS_AD & " bu dosyaya kurulacak." & vbCrLf & vbCrLf & _
            "Sayfalar, veri tablolar�, kay�t formu, panel ve raporlar olu�turulacak." & _
            IIf(gorselYok, vbCrLf & vbCrLf & "UYARI: " & KS_KLASOR & " klas�r� dosyan�n yan�nda bulunamad�; " & _
                "tasar�m g�rselsiz kurulacak.", "") & vbCrLf & vbCrLf & _
            "Devam edilsin mi?", vbQuestion + vbYesNo, KS_AD) <> vbYes Then Exit Sub
    Else
        If MsgBox(KS_AD & " zaten kurulu." & vbCrLf & vbCrLf & _
            "Onar�m modunda: kay�tlar korunur, eksik par�alar tamamlan�r, t�m sayfalar�n tasar�m� yenilenir." & _
            vbCrLf & "�nce dosyan�n yede�i al�nacak. Devam edilsin mi?", vbQuestion + vbYesNo, KS_AD) <> vbYes Then Exit Sub
        adim = "Kurulum �ncesi yedek"
        yedek = KS_YedekKopya("ONARIM_ONCESI")
    End If

    KS_Basla
    adim = "Sayfalar� haz�rlama"
    KS_Durum adim
    For Each ad In KS_Sayfalar()
        Set ws = KS_WS(CStr(ad))
        If Not ws Is Nothing Then KS_Ac ws
    Next ad
    KS_SayfalariHazirla ilk

    adim = "Tablo stili"
    KS_TabloStiliKur

    adim = "TANIMLAR sayfas�"
    KS_Durum adim
    KS_TanimlarKur

    adim = "Veri tablolar�"
    KS_Durum adim
    KS_VeriSayfalariKur

    adim = "Adland�r�lm�� listeler"
    KS_AdlariKur

    adim = "RAPORLAR sayfas�"
    KS_Durum adim
    KS_RaporKur

    adim = "KAYIT formu"
    KS_Durum adim
    KS_KayitFormKur

    adim = "KARNE sayfas�"
    KS_KarneKur

    adim = "TOPLU AKTAR sayfas�"
    KS_AktarKur

    adim = "PANEL sayfas�"
    KS_Durum adim
    KS_PanelKur

    adim = "Kurulum kayd�"
    KS_AdTanimla ETIKET, "=2"
    ThisWorkbook.Names(ETIKET).Visible = False
    If Not KS_AdVar("_KS_KORUMA") Then
        KS_AdTanimla "_KS_KORUMA", "=1"
        ThisWorkbook.Names("_KS_KORUMA").Visible = False
    End If

    adim = "Hesaplama ve panel"
    KS_Durum adim
    KS_HesaplaTumu
    KS_PanelYenile False

    adim = "Sayfa korumas�"
    For Each ad In KS_Sayfalar()
        KS_Kapat KS_WS(CStr(ad))
    Next ad

    KS_Bitir True
    KS_Log IIf(ilk, "KURULUM", "ONARIM"), "v" & KS_SURUM, IIf(Len(yedek) > 0, "Yedek: " & yedek, "")
    KS_WS(SH_PANEL).Activate
    ActiveWindow.ScrollRow = 1
    MsgBox KS_AD & " " & IIf(ilk, "kuruldu.", "onar�ld�.") & vbCrLf & vbCrLf & _
        "Ba�lang��:" & vbCrLf & _
        "1) SEVK�YATLAR > YILLIK EXCEL Y�KLE ile y�l ba�� listesini al�n." & vbCrLf & _
        "2) MALZEMELER sayfas�nda garanti s�relerini girin (sar� s�tun)." & vbCrLf & _
        "3) Ar�zalar� KAYIT > ARIZA sekmesinden girin." & vbCrLf & vbCrLf & _
        "Sayfa koruma �ifresi: " & KS_SIFRE & _
        IIf(Len(yedek) > 0, vbCrLf & "Onar�m �ncesi yedek: " & yedek, ""), vbInformation, KS_AD
    Exit Sub

Hata:
    onceki = Err.Number
    KS_Bitir True
    MsgBox "Kurulum tamamlanamad�." & vbCrLf & _
        "Ad�m: " & adim & vbCrLf & _
        "Hata: " & onceki & " / " & Err.Description & _
        IIf(Len(yedek) > 0, vbCrLf & "Yedek: " & yedek, ""), vbCritical, KS_AD
End Sub

' ---------------------------------------------------------------- sayfalar

Private Sub KS_SayfalariHazirla(ByVal ilk As Boolean)
    Dim ad As Variant, ws As Worksheet, onceki As Worksheet, i As Long, uyari As Boolean
    For Each ad In KS_Sayfalar()
        Set ws = KS_WS(CStr(ad))
        If ws Is Nothing Then
            Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
            ws.Name = CStr(ad)
        End If
        If onceki Is Nothing Then
            ws.Move Before:=ThisWorkbook.Worksheets(1)
        Else
            ws.Move After:=onceki
        End If
        Set onceki = KS_WS(CStr(ad))
        Select Case CStr(ad)
            Case SH_PANEL: onceki.Tab.Color = C_MAVI()
            Case SH_KAYIT: onceki.Tab.Color = C_YESIL2()
            Case SH_SEVK, SH_ARIZA, SH_MALZ: onceki.Tab.Color = C_LAC()
            Case SH_KARNE, SH_RAPOR: onceki.Tab.Color = C_TEAL()
            Case Else: onceki.Tab.Color = C_GRI()
        End Select
    Next ad
    If ilk Then
        uyari = Application.DisplayAlerts
        Application.DisplayAlerts = False
        For i = ThisWorkbook.Worksheets.Count To 1 Step -1
            Set ws = ThisWorkbook.Worksheets(i)
            If Not KS_BizimSayfa(ws.Name) Then
                If Application.WorksheetFunction.CountA(ws.Cells) = 0 And ws.Shapes.Count = 0 Then ws.Delete
            End If
        Next i
        Application.DisplayAlerts = uyari
    End If
End Sub

' Tabloyu olu�turur ya da mevcut tablonun ba�l�klar�n� do�rular. yeni = True ise tablo yeni kuruldu.
Private Function KS_TabloKur(ByVal ws As Worksheet, ByVal ad As String, ByVal sol As Range, _
        ByVal basliklar As Variant, ByVal genislik As Variant, ByVal bicim As Variant, _
        ByRef yeni As Boolean) As ListObject
    Dim lo As ListObject, n As Long, i As Long
    n = UBound(basliklar) - LBound(basliklar) + 1
    For i = 0 To n - 1
        ws.Columns(sol.Column + i).ColumnWidth = genislik(LBound(genislik) + i)
        ws.Range(ws.Cells(sol.Row + 1, sol.Column + i), ws.Cells(ws.Rows.Count, sol.Column + i)).NumberFormat = _
            bicim(LBound(bicim) + i)
    Next i
    Set lo = KS_LO(ad)
    yeni = lo Is Nothing
    If yeni Then
        sol.Resize(1, n).Value = basliklar
        Set lo = ws.ListObjects.Add(xlSrcRange, sol.Resize(2, n), , xlYes)
        lo.Name = ad
        For i = lo.ListRows.Count To 1 Step -1
            If Application.WorksheetFunction.CountA(lo.ListRows(i).Range) = 0 Then lo.ListRows(i).Delete
        Next i
    Else
        If lo.ListColumns.Count <> n Then
            Err.Raise vbObjectError + 7101, KS_AD, ad & " tablosunun s�tun say�s� beklenenden farkl� (" & _
                lo.ListColumns.Count & " / " & n & "). Kurulum veriye dokunmadan durduruldu."
        End If
        For i = 1 To n
            If StrComp(lo.HeaderRowRange.Cells(1, i).Value, basliklar(LBound(basliklar) + i - 1), vbTextCompare) <> 0 Then
                Err.Raise vbObjectError + 7102, KS_AD, ad & " tablosunda " & i & ". s�tun ba�l��� farkl�: '" & _
                    lo.HeaderRowRange.Cells(1, i).Value & "'. Kurulum veriye dokunmadan durduruldu."
            End If
        Next i
    End If
    lo.TableStyle = KS_STIL
    lo.ShowTableStyleRowStripes = True
    With lo.HeaderRowRange
        .WrapText = True
        .VerticalAlignment = xlCenter
        .HorizontalAlignment = xlCenter
        .Font.Bold = True
        .Font.Size = 9
        .Interior.Pattern = xlNone
    End With
    lo.HeaderRowRange.EntireRow.RowHeight = 36
    Set KS_TabloKur = lo
End Function

' Hesaplanan s�tunlar�n ba�l��� koyu turkuaz, elle girilebilen s�tunlar�n ba�l��� amber.
Private Sub KS_BaslikRenk(ByVal lo As ListObject, ByVal kolonlar As Variant, ByVal renk As Long)
    Dim k As Variant
    For Each k In kolonlar
        With lo.HeaderRowRange.Cells(1, CLng(k))
            .Interior.Color = renk
            .Font.Color = vbWhite
        End With
    Next k
End Sub

' Elle d�zenlenebilir s�tunlar: kilit a��k, a��k sar� zemin.
Private Sub KS_DuzenlenebilirSutun(ByVal lo As ListObject, ByVal kolonlar As Variant)
    Dim k As Variant, ws As Worksheet, c As Long
    Set ws = lo.Parent
    For Each k In kolonlar
        c = lo.HeaderRowRange.Cells(1, CLng(k)).Column
        ws.Range(ws.Cells(lo.HeaderRowRange.Row + 1, c), ws.Cells(ws.Rows.Count, c)).Locked = False
        With lo.HeaderRowRange.Cells(1, CLng(k))
            .Interior.Color = RGB(214, 150, 20)
            .Font.Color = vbWhite
        End With
    Next k
End Sub

Private Sub KS_VeriSayfaGenel(ByVal ws As Worksheet)
    ws.Cells.Font.Name = KS_FONT
    ws.Cells.Font.Size = 9.5
    ws.Columns(1).ColumnWidth = 2
    ws.Rows("4:" & ws.Rows.Count).RowHeight = 19
    ws.Cells.VerticalAlignment = xlCenter
End Sub

' Veri sayfas� �st b�l�m�: �er�eve (sat�r 1), ba�l�k + i�lem d��meleri (sat�r 2), tablo (sat�r 3).
Public Sub KS_VeriSayfaUst(ByVal ws As Worksheet, ByVal baslik As String, ByVal aciklama As String, ByVal dugmeler As Variant)
    Dim alt As Double, sol As Double, i As Long, n As Long, gen As Double, x As Double
    KS_SekilSil ws, "ksB_"
    alt = KS_SayfaCerceve(ws, False)
    ws.Rows(1).RowHeight = alt + 6
    ws.Rows(2).RowHeight = 44
    sol = ws.Cells(1, 2).Left
    x = sol + KS_GENISLIK
    If IsArray(dugmeler) Then
        n = (UBound(dugmeler) + 1) \ 3
        gen = 118
        x = sol + KS_GENISLIK - n * gen - (n - 1) * 6
    End If
    KS_SayfaBaslik ws, ws.Rows(2).Top + 4, baslik, aciklama, x - sol - 12
    If IsArray(dugmeler) Then
        For i = 0 To n - 1
            KS_Buton ws, "ksB_" & i, CStr(dugmeler(i * 3)), x + i * (gen + 6), ws.Rows(2).Top + 9, gen, 26, _
                CStr(dugmeler(i * 3 + 1)), CStr(dugmeler(i * 3 + 2))
        Next i
    End If
End Sub

Private Sub KS_VeriSayfalariKur()
    Dim ws As Worksheet, lo As ListObject, yeni As Boolean, tl As String, tr As String
    tl = "#,##0.00"
    tr = KS_FmtTarih()

    ' MALZEMELER
    Set ws = KS_WS(SH_MALZ)
    KS_VeriSayfaGenel ws
    Set lo = KS_TabloKur(ws, T_MALZ, ws.Range("B3"), _
        Array("Malzeme Kodu", "Malzeme Ad�", "Kategori", "Birim", "�retici", "Birim Fiyat", "Para Birimi", _
            "Garanti (Ay)", "Sevk Edilen", "Ar�zal�", "Ar�za Oran�", "Son Ar�za", "Not", "Kay�t Tarihi"), _
        Array(16, 40, 16, 9, 34, 13, 9, 10, 11, 9, 10, 12, 30, 12), _
        Array("@", "@", "@", "@", "@", tl, "@", "0", "#,##0", "#,##0", "0.0%", tr, "@", tr), yeni)
    KS_BaslikRenk lo, Array(M_SEVKMIK, M_ARIZAMIK, M_ORAN, M_SONARIZA, M_KAYIT), C_TEAL()
    KS_DuzenlenebilirSutun lo, Array(M_KAT, M_BIRIM, M_GARANTI, M_NOT)
    KS_VeriSayfaUst ws, "MALZEMELER", "Sar� ba�l�kl� s�tunlar do�rudan d�zenlenebilir. Garanti s�resi bo� sevkiyatlara da uygulan�r.", _
        Array("+ YEN� MALZEME", "KS_GIT_KAYIT_MALZ", "ana", "GARANT�S� G�R�LMEM��", "KS_F_MALZ_GARYOK", "turuncu", _
            "ARIZA VERENLER", "KS_F_MALZ_ARIZALI", "teal", "T�M�N� G�STER", "KS_F_TEMIZLE", "cizgi")
    KS_Pencere ws, 90, 3

    ' SEVK�YATLAR
    Set ws = KS_WS(SH_SEVK)
    KS_VeriSayfaGenel ws
    Set lo = KS_TabloKur(ws, T_SEVK, ws.Range("B3"), _
        Array("Sevk No", "Sevk�i", "Sevk Yeri", "Malzeme Kodu", "Malzeme Ad�", "Adet", "Birim Fiyat", _
            "Para Birimi", "Tutar (TL)", "Planlanan Teslim", "Ger�ek Geli�", "Gecikme (G�n)", "Teslim Durumu", _
            "Garanti (Ay)", "Garanti Biti�", "Garanti Durumu", "Belge / SAS No", "Seri / Lot No", "Ar�zal�", _
            "Not", "Kay�t Zaman�", "Kaydeden"), _
        Array(12, 38, 17, 14, 36, 8, 12, 8, 15, 11, 11, 9, 14, 9, 11, 18, 18, 14, 8, 30, 15, 11), _
        Array("@", "@", "@", "@", "@", "General", tl, "@", tl, tr, tr, "0", "@", "0", tr, "@", "@", "@", _
            "General", "@", "dd.mm.yyyy hh:mm", "@"), yeni)
    KS_BaslikRenk lo, Array(S_NO, S_AD, S_TUTAR, S_GECIKME, S_TDURUM, S_GARBIT, S_GDURUM, S_ARIZA, S_ZAMAN, S_KULL), C_TEAL()
    KS_DuzenlenebilirSutun lo, Array(S_GELIS, S_GARAY, S_IRS, S_SERI, S_NOT)
    KS_DurumRenkleri lo, S_TDURUM, Array("ZAMANINDA", "GEC�KMEL�", "GEC�K�YOR")
    KS_DurumRenkleri lo, S_GDURUM, Array("DEVAM", "B�TT�", "B�T�YOR")
    KS_VeriSayfaUst ws, "SEVK�YATLAR", "Ger�ek geli�, garanti, belge, seri ve not s�tunlar� do�rudan d�zenlenebilir.", _
        Array("YILLIK EXCEL Y�KLE", "KS_SAP_AKTAR", "yesil", "GARANT�S� B�TECEK", "KS_F_SEVK_GARBITIYOR", "turuncu", _
            "GEC�KENLER", "KS_F_SEVK_GECIKEN", "turuncu", "GARANT�S� G�R�LMEM��", "KS_F_SEVK_GARYOK", "teal", _
            "T�M�N� G�STER", "KS_F_TEMIZLE", "cizgi", "+ YEN� SEVK�YAT", "KS_GIT_KAYIT_SEVK", "ana")
    KS_Pencere ws, 90, 3

    ' ARIZALAR
    Set ws = KS_WS(SH_ARIZA)
    KS_VeriSayfaGenel ws
    Set lo = KS_TabloKur(ws, T_ARIZA, ws.Range("B3"), _
        Array("Ar�za No", "Ar�za Tarihi", "Malzeme Kodu", "Malzeme Ad�", "Seri No", "�retici", "Sevk�i", _
            "Sevk Yeri", "Ba�l� Sevkiyat", "Garanti Biti�", "Garanti Devam Ediyor mu?", "Garanti Bilgisi", _
            "Ar�zal� Adet", "Ar�za Tipi", "Ar�za Sebebi / A��klama", "�reticiye Bildirim", "Mail Yaz��mas�", _
            "Mail Dosyas�", "�retici D�n��", "D�n�� S�resi (G�n)", "Ar�za Devam Ediyor mu?", "��z�ld� m�?", _
            "Durum", "��z�m Tarihi", "��z�m S�resi (G�n)", "��z�m �ekli", "Tamir Maliyeti (TL)", _
            "Maliyeti Kar��layan", "�nceki Ar�za", "Tekrar", "Not", "Kay�t Zaman�", "Kaydeden"), _
        Array(12, 11, 14, 34, 14, 34, 34, 16, 12, 11, 11, 11, 8, 15, 40, 11, 40, 30, 11, 9, 11, 10, 16, 11, _
            9, 12, 13, 13, 11, 7, 26, 15, 11), _
        Array("@", tr, "@", "@", "@", "@", "@", "@", "@", tr, "@", "@", "General", "@", "@", tr, "@", "@", tr, _
            "0", "@", "@", "@", tr, "0", "@", tl, "@", tr, "0", "@", "dd.mm.yyyy hh:mm", "@"), yeni)
    KS_BaslikRenk lo, Array(A_NO, A_AD, A_URETICI, A_SEVKCI, A_YER, A_SEVK, A_GARBIT, A_KAPKAYNAK, A_DONUSGUN, _
        A_DURUM, A_COZUMGUN, A_ONCEKI, A_TEKRAR, A_ZAMAN, A_KULL), C_TEAL()
    KS_DurumRenkleri lo, A_KAPSAM, Array("EVET", "HAYIR", "BEL�RS�Z")
    KS_DurumRenkleri lo, A_DURUM, Array("��Z�LD�", "��Z�LEMED�", "DEVAM")
    KS_DurumRenkleri lo, A_DURUM, Array("��Z�LD�", "��Z�LEMED�", "�RET�C�DE"), True
    KS_VeriSayfaUst ws, "ARIZALAR", "D�zeltme i�in KAYIT > ARIZA sekmesinde ar�za numaras�n� yaz�n; kay�t forma gelir.", _
        Array("+ YEN� ARIZA", "KS_GIT_KAYIT_ARIZA", "ana", "DEVAM EDENLER", "KS_F_ARIZA_ACIK", "turuncu", _
            "�RET�C�DE", "KS_F_ARIZA_URETICIDE", "turuncu", "��Z�LENLER", "KS_F_ARIZA_COZULEN", "yesil", _
            "GARANT� KAPSAMINDA", "KS_F_ARIZA_GARANTI", "teal", "T�M�N� G�STER", "KS_F_TEMIZLE", "cizgi")
    KS_Pencere ws, 90, 3

    ' G�NL�K
    Set ws = KS_WS(SH_LOG)
    KS_VeriSayfaGenel ws
    Set lo = KS_TabloKur(ws, T_LOG, ws.Range("B3"), _
        Array("Zaman", "Kullan�c�", "��lem", "Kay�t No", "Detay"), _
        Array(18, 16, 22, 16, 100), _
        Array("dd.mm.yyyy hh:mm:ss", "@", "@", "@", "@"), yeni)
    KS_VeriSayfaUst ws, "��LEM G�NL���", "Her kay�t, g�ncelleme, aktar�m ve yedek burada iz b�rak�r. Silinmez.", _
        Array("TANIMLAR", "KS_GIT_TANIM", "cizgi", "TOPLU AKTAR", "KS_GIT_AKTAR", "cizgi")
    KS_Pencere ws, 90, 3
End Sub

' Durum s�tununa ko�ullu renk: iyi = ye�il, k�t� = k�rm�z�, uyar� = turuncu (metnin ba��na g�re).
Private Sub KS_DurumRenkleri(ByVal lo As ListObject, ByVal kolon As Long, ByVal deger As Variant, _
        Optional ByVal ekle As Boolean = False)
    Dim r As Range, i As Long, renk As Variant, fc As Object
    Set r = lo.ListColumns(kolon).Range
    Set r = r.Offset(1).Resize(100000)
    If Not ekle Then r.FormatConditions.Delete
    renk = Array(C_YESIL(), C_KIRMIZI(), C_TURUNCU())
    For i = 0 To 2
        If Len(deger(i)) > 0 And Not (ekle And i < 2) Then
            Set fc = r.FormatConditions.Add(Type:=xlTextString, String:=CStr(deger(i)), TextOperator:=xlBeginsWith)
            fc.Font.Color = renk(i)
            fc.Font.Bold = True
        End If
    Next i
End Sub

' ---------------------------------------------------------------- TANIMLAR (Y�NET�M)

Private Sub KS_TanimlarKur()
    Dim ws As Worksheet, lo As ListObject, yeni As Boolean, i As Long, v As Variant, alt As Double, sol As Double
    Set ws = KS_WS(SH_TANIM)
    ws.Cells.Font.Name = KS_FONT
    ws.Cells.Font.Size = 9.5
    ws.Columns(1).ColumnWidth = 2

    ' Sevk�i listesinde SAP bi�imi (kod + ad) anahtard�r; ayn� ad farkl� kodla gelebilir.
    Set lo = KS_TabloKur(ws, T_SEVKCI, ws.Range("B3"), _
        Array("Sevk�i (SAP)", "Tedarik�i Kodu", "Tedarik�i Ad�", "T�r", "Sevk Yerleri", "Not"), _
        Array(44, 13, 34, 15, 30, 40), Array("@", "@", "@", "@", "@", "@"), yeni)
    If yeni Then KS_TedarikciEkle
    ws.Columns("H").ColumnWidth = 2
    Set lo = KS_TabloKur(ws, T_YER, ws.Range("I3"), Array("Sevk Yeri", "�retim Yeri", "�l"), _
        Array(22, 11, 12), Array("@", "@", "@"), yeni)
    If yeni Then
        KS_Tohum lo, Array("�EDA� TRABZON", "�EDA� R�ZE", "�EDA� ARTV�N", "�EDA� G�RESUN", "�EDA� G�M��HANE"), _
            Array("7152", "7151", "7155", "7154", "7153")
        lo.ListColumns(3).DataBodyRange.Value = Application.Transpose( _
            Array("Trabzon", "Rize", "Artvin", "Giresun", "G�m��hane"))
    End If
    ws.Columns("L").ColumnWidth = 2
    Set lo = KS_TabloKur(ws, T_KAT, ws.Range("M3"), Array("Kategori"), Array(20), Array("@"), yeni)
    If yeni Then KS_Tohum lo, Array("Kablo", "Trafo", "Saya�", "Kesici / Ay�r�c�", "Direk / Travers", _
        "�zolat�r", "Parafudr", "Pano / H�cre", "Redres�r / Ak�", "Ayd�nlatma", "�SG Malzemesi", "Hizmet", "Di�er")
    ws.Columns("N").ColumnWidth = 2
    Set lo = KS_TabloKur(ws, T_BIRIM, ws.Range("O3"), Array("Birim"), Array(12), Array("@"), yeni)
    If yeni Then KS_Tohum lo, Array("ADT", "M", "KG", "SET", "TAKIM", "AY", "G�N")
    ws.Columns("P").ColumnWidth = 2
    Set lo = KS_TabloKur(ws, T_TIP, ws.Range("Q3"), Array("Ar�za Tipi"), Array(22), Array("@"), yeni)
    If yeni Then KS_Tohum lo, Array("Elektriksel", "Mekanik", "�zolasyon", "�retim Hatas�", _
        "Montaj Kaynakl�", "Nakliye Hasar�", "Yaz�l�m / Haberle�me", "Di�er")
    ws.Columns("R").ColumnWidth = 2
    Set lo = KS_TabloKur(ws, T_COZUM, ws.Range("S3"), Array("��z�m �ekli"), Array(18), Array("@"), yeni)
    If yeni Then KS_Tohum lo, Array("Tamir", "De�i�im", "�ade", "Hurda", "Beklemede")
    ws.Columns("T").ColumnWidth = 2
    Set lo = KS_TabloKur(ws, T_KARS, ws.Range("U3"), Array("Maliyeti Kar��layan"), Array(20), Array("@"), yeni)
    If yeni Then KS_Tohum lo, Array("�retici", "Kurum", "Y�klenici", "Payla��ml�")
    ws.Columns("V").ColumnWidth = 2
    Set lo = KS_TabloKur(ws, T_KUR, ws.Range("W3"), Array("Para Birimi", "Kur (TL)"), Array(12, 12), _
        Array("@", "#,##0.0000"), yeni)
    If yeni Then
        KS_Tohum lo, Array("TRY", "USD", "EUR", "GBP"), Array(1, Empty, Empty, Empty)
    End If
    ws.Columns("Y").ColumnWidth = 2

    ' Parametreler
    ws.Columns("Z").ColumnWidth = 46
    ws.Columns("AA").ColumnWidth = 15
    ws.Columns("AB").ColumnWidth = 2
    KS_TabloBaslik ws.Range("Z3:AA3"), Array("PARAMETRE", "DE�ER")
    v = Array( _
        Array("Garanti biti� uyar�s� (g�n)", "pGarUyari", 60, "0"), _
        Array("Kalite skoru: ar�za oran� katsay�s� (puan / %1)", "pKatAriza", 5, "0.0"), _
        Array("Kalite skoru: gecikme katsay�s� (puan / g�n)", "pKatGecikme", 1, "0.0"), _
        Array("Kalite skoru: �retici d�n�� katsay�s� (puan / g�n)", "pKatDonus", 0.5, "0.0"), _
        Array("Yedek hat�rlatma aral��� (g�n)", "pYedekGun", 7, "0"), _
        Array("Son yedek", "pSonYedek", Empty, "dd.mm.yyyy hh:mm"))
    For i = 0 To UBound(v)
        ws.Cells(4 + i, "Z").Value = v(i)(0)
        KS_AdHucre CStr(v(i)(1)), ws.Cells(4 + i, "AA")
        If KS_Bos(ws.Cells(4 + i, "AA").Value) And Not IsEmpty(v(i)(2)) Then ws.Cells(4 + i, "AA").Value = v(i)(2)
        ws.Cells(4 + i, "AA").NumberFormat = v(i)(3)
        ws.Cells(4 + i, "AA").HorizontalAlignment = xlCenter
    Next i
    KS_TabloGovde ws.Range("Z4:AA" & 4 + UBound(v))

    ' A��l�r liste kaynaklar�
    ws.Columns("AC").ColumnWidth = 10
    ws.Columns("AD").ColumnWidth = 12
    ws.Columns("AE").ColumnWidth = 12
    KS_TabloBaslik ws.Range("AC3:AE3"), Array("YIL", "EVET / HAYIR", "��Z�LD� M�")
    ws.Range("AD4:AD5").Value = Application.Transpose(Array("EVET", "HAYIR"))
    ws.Range("AE4:AE6").Value = Application.Transpose(Array("EVET", "HAYIR", "KISMEN"))
    KS_TabloGovde ws.Range("AD4:AE6")
    KS_YilListesiGuncelle

    ' �st b�l�m ve y�netim ara�lar�
    KS_VeriSayfaUst ws, "Y�NET�M  /  TANIMLAR", "A��l�r listelerin kayna��, d�viz kurlar� ve parametreler. Tablolara sat�r ekleyebilirsiniz.", _
        Array("TOPLU AKTAR", "KS_GIT_AKTAR", "koyu", "��LEM G�NL���", "KS_GIT_LOG", "koyu", _
            "YEDEK AL", "KS_YEDEK_AL", "ana")
    KS_SekilSil ws, "ksArac_"
    KS_Yazi ws, "ksArac_B", "Y�NET�M ARA�LARI", ws.Range("Z12").Left, ws.Range("Z12").Top, 300, 18, 10.5, True, _
        C_LAC(), msoAlignLeft
    v = Array("TEDAR�K�� L�STES�N� Y�KLE", "KS_TEDARIKCI_YUKLE", "koyu", _
        "T�M�N� YEN�DEN HESAPLA", "KS_YENIDEN_HESAPLA", "koyu", _
        "SAYFA KORUMASI A� / KAPAT", "KS_KORUMA_DEGISTIR", "koyu", _
        "TASARIMI YEN�LE (ONARIM)", "KALITESORA_KUR", "teal", _
        "�RNEK VER� Y�KLE (deneme)", "KS_ORNEK_VERI_YUKLE", "cizgi", _
        "�RNEK VER�Y� S�L", "KS_ORNEK_VERI_SIL", "cizgi", _
        "VBA KODUNU DI�A AKTAR", "KS_VBA_DISARI_AKTAR", "gri")
    For i = 0 To UBound(v) \ 3
        KS_Buton ws, "ksArac_" & i, CStr(v(i * 3)), ws.Range("Z13").Left, ws.Range("Z12").Top + 24 + i * 30, _
            ws.Range("Z13").Width + ws.Range("AA13").Width, 24, CStr(v(i * 3 + 1)), CStr(v(i * 3 + 2))
    Next i
    KS_Pencere ws, 90, 3
End Sub

Private Sub KS_Tohum(ByVal lo As ListObject, ByVal ilk As Variant, Optional ByVal ikinci As Variant)
    Dim v() As Variant, i As Long, n As Long
    n = UBound(ilk) - LBound(ilk) + 1
    ReDim v(1 To n, 1 To lo.ListColumns.Count)
    For i = 1 To n
        v(i, 1) = ilk(LBound(ilk) + i - 1)
        If Not IsMissing(ikinci) Then v(i, 2) = ikinci(LBound(ikinci) + i - 1)
    Next i
    KS_TopluEkle lo, v, n
End Sub

' Y�l listesi: T�M� + verideki ilk y�ldan bu y�la (en az son 5 y�l).
Public Sub KS_YilListesiGuncelle()
    Dim ws As Worksheet, ilkYil As Long, y As Long, i As Long, a As Variant, d As Date, lo As ListObject
    Dim korumali As Boolean
    Set ws = KS_WS(SH_TANIM)
    If ws Is Nothing Then Exit Sub
    korumali = ws.ProtectContents
    KS_Ac ws
    ilkYil = Year(Date) - 4
    Set lo = KS_LO(T_SEVK)
    If Not lo Is Nothing Then
        a = KS_Veri(lo)
        If IsArray(a) Then
            For i = 1 To UBound(a, 1)
                If KS_Tarih(a(i, S_PLAN), d) Then If Year(d) < ilkYil Then ilkYil = Year(d)
                If KS_Tarih(a(i, S_GELIS), d) Then If Year(d) < ilkYil Then ilkYil = Year(d)
            Next i
        End If
    End If
    If ilkYil < Year(Date) - 25 Then ilkYil = Year(Date) - 25
    ws.Range("AC4:AC40").ClearContents
    ws.Range("AC4").Value = "T�M�"
    i = 5
    For y = Year(Date) + 1 To ilkYil Step -1
        ws.Cells(i, "AC").Value = y
        i = i + 1
    Next y
    KS_TabloGovde ws.Range("AC4:AC" & i - 1)
    KS_AdTanimla "lstYil", "='" & ws.Name & "'!$AC$4:$AC$" & i - 1
    KS_AdTanimla "lstYilSayi", "='" & ws.Name & "'!$AC$5:$AC$" & i - 1
    If korumali Then KS_Kapat ws
End Sub

' ---------------------------------------------------------------- adlar

Private Sub KS_AdlariKur()
    KS_AdTanimla "lstMalzeme", "=INDEX(" & T_MALZ & ",0,1)"
    KS_AdTanimla "lstMalzemeAd", "=INDEX(" & T_MALZ & ",0,2)"
    KS_AdTanimla "lstSevk", "=INDEX(" & T_SEVK & ",0,1)"
    KS_AdTanimla "lstAriza", "=INDEX(" & T_ARIZA & ",0,1)"
    KS_AdTanimla "lstSevkci", "=INDEX(" & T_SEVKCI & ",0,1)"
    KS_AdTanimla "lstYer", "=INDEX(" & T_YER & ",0,1)"
    KS_AdTanimla "lstKategori", "=INDEX(" & T_KAT & ",0,1)"
    KS_AdTanimla "lstBirim", "=INDEX(" & T_BIRIM & ",0,1)"
    KS_AdTanimla "lstTip", "=INDEX(" & T_TIP & ",0,1)"
    KS_AdTanimla "lstCozum", "=INDEX(" & T_COZUM & ",0,1)"
    KS_AdTanimla "lstKarsilayan", "=INDEX(" & T_KARS & ",0,1)"
    KS_AdTanimla "lstPB", "=INDEX(" & T_KUR & ",0,1)"
    KS_AdTanimla "lstEvetHayir", "='" & SH_TANIM & "'!$AD$4:$AD$5"
    KS_AdTanimla "lstCozuldu", "='" & SH_TANIM & "'!$AE$4:$AE$6"
End Sub

' A��l�r liste ekler. sert = False ise listede olmayan de�ere uyar�yla izin verilir.
Public Sub KS_Liste(ByVal r As Range, ByVal ad As String, Optional ByVal sert As Boolean = True)
    r.Validation.Delete
    r.Validation.Add Type:=xlValidateList, AlertStyle:=IIf(sert, xlValidAlertStop, xlValidAlertInformation), _
        Formula1:="=" & ad
    r.Validation.IgnoreBlank = True
    r.Validation.InCellDropdown = True
    r.Validation.ShowError = True
    r.Validation.ErrorTitle = KS_AD
    r.Validation.ErrorMessage = "Listede olmayan bir de�er girdiniz. Yeni de�erler TANIMLAR sayfas�ndan eklenir."
End Sub

Public Sub KS_TarihDogrulama(ByVal r As Range)
    r.Validation.Delete
    r.Validation.Add Type:=xlValidateDate, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, _
        Formula1:=CStr(CLng(DateSerial(1990, 1, 1))), Formula2:=CStr(CLng(DateSerial(2100, 12, 31)))
    r.Validation.ErrorTitle = KS_AD
    r.Validation.ErrorMessage = "Ge�erli bir tarih girin (gg.aa.yyyy)."
End Sub

Public Sub KS_SayiDogrulama(ByVal r As Range)
    r.Validation.Delete
    r.Validation.Add Type:=xlValidateDecimal, AlertStyle:=xlValidAlertStop, Operator:=xlGreaterEqual, _
        Formula1:="0"
    r.Validation.ErrorTitle = KS_AD
    r.Validation.ErrorMessage = "S�f�r veya pozitif bir say� girin."
End Sub
