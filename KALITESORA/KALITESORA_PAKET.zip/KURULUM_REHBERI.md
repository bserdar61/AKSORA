# KALİTESORA v2.7 — Kurulum ve Kullanım

**Çoruh Bölgesi malzeme kalite, garanti ve arıza takip merkezi.** Tamamen VBA ile çalışır; Excel dışında bir şey gerektirmez.
Tasarım ailesi AKSORA ile aynıdır: banner görseli, açık zemin, gölgeli beyaz kartlar, hizalı sekme çubuğu.

> **Not:** Kod bu ortamda Excel'de çalıştırılamadı. Statik denetimden geçti: blok eşleşmesi, tanımsız
> değişken, anahtar kelime çakışması, yordam ortasında tanım, parametre sayısı ve düğme makro adları.
> Bir hata çıkarsa mesajdaki **Adım** ve **Hata** satırlarının ekran görüntüsünü gönderin.

---

## 1. Kurulum (hazır paket)

1. `KALITESORA_PAKET.zip` dosyasını bir klasöre açın. Klasörde şunlar olmalı:
   ```
   KALITESORA.xlsm
   KALITESORA_GORSEL\   (banner, zemin, logo)
   ```
   Görsel klasörü dosyanın **yanında** durmalıdır; kurulum görselleri buradan okuyup dosyaya gömer.
2. `KALITESORA.xlsm` > sağ tık > **Özellikler** > **Engellemeyi kaldır** > Tamam.
3. Dosyayı açın > **İçeriği Etkinleştir**. Kurulum kendiliğinden başlar; **Evet** deyin.
4. Kurulum bitince dosyayı kaydedin. Bundan sonra görsel klasörü gerekmez.

Daha önce v1 kuruluysa: v2'de tablo yapısı değişti. Yeni paketi **boş** olarak kurun; v1'de veri girdiyseniz
haber verin, aktarma yolunu birlikte yapalım.

---

## 1a. Uygulama modu ve ekran doldurma (v2.1)

- Dosya açılınca **uygulama modu** devreye girer: Excel şeridi, formül çubuğu, satır/sütun başlıkları ve
  kılavuz çizgileri gizlenir. Başka bir Excel dosyasına geçince ya da dosya kapanınca Excel görünümü geri gelir.
- Her sayfa açıldığında ve pencere boyutu değiştiğinde ekran kendiliğinden doldurulur: banner ve sekme bandı
  pencere genişliğini tam kaplayacak şekilde yakınlaştırma ayarlanır.
- Excel görünümüne geçmek için: PANEL > **EXCEL / UYGULAMA** düğmesi (YÖNETİM sayfasında da var).
- v2.0 kurulu dosyada v2.1 ilk açıldığında **tasarım güncellemesi kendiliğinden** uygulanır; kayıtlar korunur,
  önce yedek alınır. Bu sırada `KALITESORA_GORSEL` klasörü dosyanın yanında olmalı; klasör yoksa mevcut banner korunur.
- Tablo başlıkları tek renk (lacivert). Elle yazılabilen sütunlar her sayfanın açıklama satırında belirtilir.

## 2. Sayfalar

| Sekme | İçerik |
|---|---|
| **PANEL** | 4 özet kartı (sevkiyat, arıza, garanti, üretici dönüşü) ve 4 uyarı kartı: garantisi bitecek, teslimatı geciken, üreticide bekleyen, garantisi girilmemiş. **Karta tıklayınca ilgili liste süzülmüş açılır.** Altta sevk yerine göre özet ve durum özeti (kalem / tutar / pay) tabloları. |
| **KAYIT** | Sekmeli tek form: 01 MALZEME · 02 SEVKİYAT · 03 ARIZA. **Kod ya da ad yazınca hafızadaki her şey dolar**; sağdaki HAFIZA kartında geçmiş görünür. Kayıtlı numara yazılırsa kayıt forma gelir; KAYDET yeni kayıt ekler ya da günceller. |
| **SEVKİYATLAR** | **YILLIK EXCEL YÜKLE** (SAP / ÖRNEK.xlsx biçimi), hazır süzgeçler. Sarı başlıklı sütunlar (Gerçek Geliş, **Garanti (Ay)**, Belge No, Seri, Not) doğrudan düzenlenir; hesaplar kendiliğinden güncellenir. |
| **ARIZALAR** | Tüm arızalar; süzgeçler (devam eden, üreticide, çözülen, garanti kapsamında). Mail dosyası sütunu tıklanabilir bağlantıdır. |
| **MALZEMELER** | Sade ana liste. **Garanti (Ay)** buradan girilirse garantisi boş tüm sevkiyatlarına uygulanır. |
| **KARNE** | Tek arama kutusu: malzeme kodu / adı **ya da** üretici kodu / adı. Uygun karne kendiliğinden açılır. Ayrıca **TEDARİKÇİ SIRALAMASI** (kalite skoru A-D). |
| **RAPORLAR** | 5 yıllık karşılaştırma, aylık dağılım, 2 grafik. |
| **YÖNETİM** | TANIMLAR (sevkçi, sevk yeri, kategori, **döviz kurları**, parametreler), TOPLU AKTAR, İŞLEM GÜNLÜĞÜ ve yönetim araçları. |

---

## 3. Arıza kaydı nasıl akar?

1. **Arıza Tarihi**, **Malzeme Kodu** ya da **Malzeme Adı** girilir. Üretici, bağlı sevkiyat, sevk yeri ve garanti bitişi dolar.
2. **Seri No** girilirse aynı seri numaralı sevkiyat seçilir. Seri yoksa arıza tarihinden önceki en son teslim seçilir.
3. **Garanti devam ediyor mu?** otomatik EVET/HAYIR gelir. Elle değiştirilirse "ELLE" olarak saklanır.
4. **Arıza Sebebi / Açıklama**, **Üretici ile Mail Yazışması** (yapıştırılır) ve **DOSYA EKLE** girilir.
   DOSYA EKLE ile .msg / .eml / .pdf eklenir; kayıtta `KALITESORA_MAILLER\ARZ-xxxxxx\` klasörüne kopyalanır.
5. **Arıza devam ediyor mu?** ve **Çözüldü mü?** (EVET / HAYIR / KISMEN) seçilir. Durum buna göre hesaplanır:
   ÇÖZÜLDÜ · KISMEN ÇÖZÜLDÜ · ÇÖZÜLEMEDİ · ÜRETİCİDE · DEVAM EDİYOR.

---

## 4. Yıllık Excel (SAP) yükleme

SEVKİYATLAR > **YILLIK EXCEL YÜKLE** > dosya > başlangıç tarihi.

- Başlıklar adla bulunur (ÖRNEK.xlsx'teki gibi; *Tedarikçi adı* ve *Şirketin adı* sütunları da desteklenir).
- TANIMLAR'da olmayan üretim yerleri bulunursa sorulur: eklensin mi, atlansın mı.
- Aynı SAS belge + kalem + malzeme ikinci kez aktarılmaz; aktarım tekrar çalıştırılabilir.
- Döviz fiyatlar olduğu gibi saklanır; TL tutar **YÖNETİM > Kur (TL)** tablosuyla hesaplanır. Kur girilmezse tutar boş kalır.
- SAP'ta mal giriş tarihi ve garanti süresi yok:
  - **Geliş tarihi** için aktarımda sorulur (tamamen teslim alınan kalemlerde SAP teslimat tarihi, yaklaşık olarak).
  - **Garanti süresi** için MALZEMELER > **GARANTİSİ GİRİLMEMİŞ** süzgeciyle her malzemeye bir kez girin. Aynı malzemenin boş garantili tüm sevkiyatlarına uygulanır.

---

## 5. Saklama, yedek, güvenlik

- Hiçbir makro gerçek kaydı kendiliğinden silmez (yalnız **ÖRNEK VERİ** notlu deneme satırları silinebilir).
- Kurulum, aktarım ve SAP yüklemesi öncesinde `KALITESORA_YEDEK` klasörüne otomatik yedek alınır. Son yedek 7 günü geçerse açılışta sorulur.
- Excel tablosu ~1 milyon satır taşır; 5+ yıl için yeterlidir.
- Sayfa koruma şifresi: **`KS2026`** (YÖNETİM > Sayfa koruması aç / kapat).

---

## 6. Elle kurulum (gerekirse)

1. Boş bir `.xlsm` dosyasının yanına `KALITESORA_GORSEL` klasörünü koyun.
2. Güven Merkezi > Makro Ayarları > "VBA proje nesne modeline erişime güven" seçeneğini açın.
3. Alt+F11 ile `vba\modKS_YUKLEYICI.bas` dosyasını içe aktarın.
4. Alt+F8 ile `KALITESORA_YUKLE` makrosunu çalıştırın.

`.bas` dosyaları Windows-1254 (Türkçe) kodlamasındadır.

## v2.3 yenilikleri
- Açılışta tasarım güncellemesi kendiliğinden uygulanır (önce yedek alınır, kayıtlar korunur).
- **ARA** düğmesi: SEVKİYATLAR / ARIZALAR / MALZEMELER tablolarında kod, ad, seri veya üreticiye göre hızlı süzme.
- **PDF**: RAPORLAR ve KARNE sayfaları tek tıkla `KALITESORA_RAPOR` klasörüne yatay PDF olarak kaydedilir.
- **ÜRETİCİYE MAİL**: KAYIT > Arıza ekranından Outlook taslağı hazırlanır (Outlook yoksa metin alana yazılır); bildirim tarihi boşsa bugün yazılır.
- Mail dosyası **AÇ** düğmesi; eklenen mail/sohbet dosyası doğrudan açılır.
- Tarih ve sayı sütunlarına giriş denetimi; hesaplanan sütunlar ve tablo altı kilitli.

## v2.4 yenilikleri
- **Bölge filtresi:** Yıllık aktarımda Fırat bölgesi üretim yerleri (FEDAŞ 720x, Fırat Aksa 710x) ve TANIMLAR'da ili Çoruh dışı olan sevk yerleri kendiliğinden atlanır. Sevk yeri, SAP üretim yeri koduyla eşleştirilir.
- **BÖLGE DIŞI KAYITLARI TEMİZLE** (YÖNETİM): Daha önce içeri alınmış Çoruh dışı sevkiyatları ve yalnız onlar için açılmış malzeme kartlarını siler. Önce yedek alınır; arızaya bağlı sevkiyat korunur. v2.4'e geçişte bir kez sorulur.
- **Aynı sipariş kaleminin farklı teslim tarihli parçaları** artık ayrı sevkiyat olarak alınır (yineleme anahtarı: SAS + kalem + malzeme + planlanan teslim).
- **KURLARI GÜNCELLE (TCMB)** (YÖNETİM): Günlük döviz satış kurlarını çeker ve TL tutarları yeniden hesaplar. Kur eksikse aktarım sonunda önerilir.
- **GELİŞ GİR** (SEVKİYATLAR): Seçili satırlara toplu gerçek geliş tarihi yazar. **P** yazılırsa her satıra kendi planlanan teslim tarihi yazılır. Dolu geliş tarihleri değişmez.
- **GARANTİ GİR** (MALZEMELER): Seçili malzemelere toplu garanti süresi (ay) yazar. Bu süre, garantisi girilmemiş sevkiyatlarına uygulanır. Dolu değerler değişmez.
- **Firma birleştirme:** Aynı firma farklı SAP satıcı koduyla gelse de (ör. HALİÇ 1300000329 / 1300001389) KARNE ve tedarikçi sıralamasında tek firma sayılır.
- **PANEL il bazında özet:** ÇEDAŞ ve Çoruh Aksa sevk yerleri il altında birleşir; 5 Çoruh ili her zaman görünür.

## v2.5 yenilikleri
- **Yeni görsel dil:** Karadeniz dağları, orman, enerji hattı ve ışıklı Çoruh bölge haritası içeren banner; ikonlu koyu sekme bandı (aktif sekme degrade); her sayfada ikon rozeti; panel kartlarında ikonlar; degrade ve gölgeli düğmeler; dağ silüetli açık zemin.
- Görseller `KALITESORA_GORSEL` klasöründe (.jpg / .png). Klasör dosyanın yanında olmalı; yoksa önceki banner korunur ve sekmeler şekille çizilir.
- **Yıllık aktarım - devreden siparişler:** Başlangıç tarihinden önce teslim tarihli ama teslimatı tamamlanmamış siparişler sorulur ve istenirse alınır.
- **Bölge dışı kalemler:** Aktarımda sorulur; varsayılan atlamaktır.

## v2.6 düzeltmeleri
- **Süzgeç hatası giderildi:** Liste süzülmüşken (ör. GARANTİSİ BİTECEK) yapılan aktarım ya da hesaplama, Excel'in görünür hücrelere yazması yüzünden yeni satırları karıştırıyordu. Artık her toplu yazmadan önce süzgeç kaldırılıyor ve sonra geri uygulanıyor. Aktarım başında süzgeçler kapatılıyor.
- **Otomatik onarım:** Açılışta aynı Sevk No'lu ya da #N/A içeren bozuk satırlar silinir (önce yedek alınır). Ardından yıllık listenin yeniden yüklenmesi önerilir; yalnız eksik satırlar eklenir. YÖNETİM > SEVKİYAT TABLOSUNU ONAR ile elle de çalıştırılabilir.
- **Boş süzgeç:** Uyan kaydı olmayan süzgeç düğmesi tabloyu boş göstermez; "uyan kayıt yok" der ve tüm liste görünür kalır.

## "İçeriği Etkinleştir" neden her seferinde çıkıyor?
İnternetten, e-postadan ya da ZIP içinden gelen dosyalara Windows "internetten geldi" işareti koyar ve Excel bu dosyalarda makroları durdurur. Her yeni sürüm yeni bir indirme olduğu için uyarı yeniden çıkar. Kalıcı çözüm bir kez yapılır:
1. Excel'de **Dosya > Seçenekler > Güven Merkezi > Güven Merkezi Ayarları > Güvenilir Konumlar**.
2. **Yeni konum ekle** > KALİTESORA klasörünü seçin (ör. `C:\Users\...\Desktop\KALİTESORA`).
3. **Bu konumun alt klasörleri de güvenilir** kutusunu işaretleyin > Tamam.
4. Yeni sürümleri hep bu klasöre, eskisinin üzerine çıkarın.

Ek yol: ZIP'i açmadan önce sağ tık > Özellikler > **Engellemeyi kaldır** > Tamam. Kurum bilgisayarında BT ilkesi güvenilir konumları kapattıysa, klasörün eklenmesini BT'den isteyin. Aynı adımlar YÖNETİM > MAKRO UYARISI NASIL KALKAR? düğmesinde de yazılı.

## v2.7 düzeltmeleri
- **Düğmeler başka sayfaya atıyordu:** Sekme bandı tek görsel ve üstünde 8 görünmez tıklama alanından oluşuyordu. Büyük ya da ikinci ekranda Excel'in tıklama noktası kayınca, banda yakın düğmelere (özellikle KARNE'dekilere) basmak bu görünmez alanlara denk geliyor ve başka sayfa açılıyordu. Artık her sekme kendi görseli; görünmez alan kalmadı. Açık sayfanın sekmesine tıklamak hiçbir şey yapmaz.
- **KARNE:** Düğmeler artık bütün tabloları yeniden hesaplamıyor, yalnız karneyi çiziyor (daha hızlı). İşlem bitince sayfa her zaman KARNE'de kalıyor.
- Yeni sekme görselleri: `KALITESORA_GORSEL\KALITESORA_NAV_T0_A.jpg` … `T7_P.jpg`. Klasör güncellenmezse sekmeler şekille çizilir; düzeltme yine geçerlidir.
