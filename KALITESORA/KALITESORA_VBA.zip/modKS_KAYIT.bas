Attribute VB_Name = "modKS_KAYIT"
Option Explicit

' KAYIT sayfas�: �� kartl� giri� formu (Malzeme / Sevkiyat / Ar�za) ve ortak do�rulama motoru.
' Toplu aktar�m da ayn� Hazirla fonksiyonlar�n� kullan�r; kurallar tek yerde durur.

Private dMalz As Object, aMalz As Variant
Private dSevk As Object, aSevk As Variant
Private dSevkci As Object, dYer As Object, dIrs As Object
Private mSevkSayac As Long, mArizaSayac As Long
Private mOtoTanim As Boolean

Private Const KART_UST As Long = 7
Private Const ALAN_ILK As Long = 9
Private Const BUTON_SATIR As Long = 28

' ================================================================ ba�lam

Public Sub KS_BaglamYukle()
    Dim i As Long, k As String, loS As ListObject
    KS_ParamYukle
    Set dMalz = CreateObject("Scripting.Dictionary")
    aMalz = KS_Veri(KS_LOZ(T_MALZ))
    If IsArray(aMalz) Then
        For i = 1 To UBound(aMalz, 1)
            dMalz(KS_Anahtar(aMalz(i, M_KOD))) = i
        Next i
    End If
    Set dSevk = CreateObject("Scripting.Dictionary")
    Set dIrs = CreateObject("Scripting.Dictionary")
    Set loS = KS_LOZ(T_SEVK)
    aSevk = KS_Veri(loS)
    If IsArray(aSevk) Then
        For i = 1 To UBound(aSevk, 1)
            dSevk(KS_Anahtar(aSevk(i, S_NO))) = i
            k = KS_Anahtar(aSevk(i, S_IRS))
            If Len(k) > 0 Then dIrs(k & "|" & KS_Anahtar(aSevk(i, S_KOD))) = KS_Metin(aSevk(i, S_NO))
        Next i
    End If
    Set dSevkci = KS_Sozluk(T_SEVKCI)
    Set dYer = KS_Sozluk(T_YER)
    mSevkSayac = KS_EnBuyukNo(loS, "SVK-")
    mArizaSayac = KS_EnBuyukNo(KS_LOZ(T_ARIZA), "ARZ-")
    mOtoTanim = False
End Sub

' Toplu aktar�mda reddedilen yeni sevkiyat�n numaras� bir sonrakine b�rak�l�r.
Public Sub KS_SevkSayacGeri()
    mSevkSayac = mSevkSayac - 1
End Sub

Public Sub KS_OtoTanimAyarla(ByVal acik As Boolean)
    mOtoTanim = acik
End Sub

Public Function KS_MalzemeVar(ByVal kod As Variant) As Boolean
    KS_MalzemeVar = dMalz.Exists(KS_Anahtar(kod))
End Function

Public Sub KS_MalzemeKaydiEkle(ByVal kod As Variant)
    dMalz(KS_Anahtar(kod)) = 0
End Sub

' Listede olmayan tan�m� toplu aktar�mda iste�e ba�l� ekler.
Private Function KS_TanimKontrol(ByVal d As Object, ByVal tablo As String, ByVal deger As String, _
        ByVal alan As String, ByRef hata As String) As Boolean
    Dim lo As ListObject, v As Variant, korumali As Boolean
    If d.Exists(KS_Anahtar(deger)) Then
        KS_TanimKontrol = True
        Exit Function
    End If
    If Not mOtoTanim Then
        hata = alan & " TANIMLAR listesinde yok: " & deger
        Exit Function
    End If
    Set lo = KS_LOZ(tablo)
    v = KS_BosSatir(lo.ListColumns.Count)
    v(1, 1) = deger
    If tablo = T_SEVKCI And Len(deger) > 11 Then
        If Mid$(deger, 11, 1) = " " And IsNumeric(Left$(deger, 10)) Then
            v(1, 2) = Left$(deger, 10)
            v(1, 3) = Mid$(deger, 12)
        End If
    End If
    v(1, lo.ListColumns.Count) = "Toplu aktar�mda eklendi"
    korumali = lo.Parent.ProtectContents
    KS_Ac lo.Parent
    KS_SatirYaz lo, 0, v
    If korumali Then KS_Kapat lo.Parent
    d(KS_Anahtar(deger)) = lo.ListRows.Count
    KS_TanimKontrol = True
End Function

' ================================================================ do�rulama motoru

' g: Kod, Ad, Kategori, Birim, �retici, Birim Fiyat, Garanti (Ay), Not
Public Function KS_MalzemeHazirla(ByVal g As Variant, ByVal idx As Long, ByRef satir As Variant, _
        ByRef hata As String) As Boolean
    Dim kod As String, fiyat As Double, gar As Double
    hata = ""
    kod = KS_Metin(g(0))
    If Len(kod) = 0 Then hata = "Malzeme kodu bo� olamaz.": Exit Function
    If Len(kod) > 40 Then hata = "Malzeme kodu 40 karakteri ge�emez.": Exit Function
    If idx = 0 And dMalz.Exists(KS_Anahtar(kod)) Then hata = "Bu malzeme kodu zaten kay�tl�: " & kod: Exit Function
    If Len(KS_Metin(g(1))) = 0 Then hata = "Malzeme ad� bo� olamaz.": Exit Function
    If Not KS_Sayi(g(5), fiyat) Then hata = "Birim fiyat say� olmal�.": Exit Function
    If fiyat < 0 Then hata = "Birim fiyat negatif olamaz.": Exit Function
    If Not KS_Sayi(g(6), gar) Then hata = "Garanti s�resi (ay) girilmeli.": Exit Function
    If gar < 0 Or gar > 240 Or gar <> Int(gar) Then hata = "Garanti s�resi 0-240 aras� tam ay olmal�.": Exit Function
    If idx = 0 Then
        satir = KS_BosSatir(M_KOLON)
        satir(1, M_KAYIT) = Date
    Else
        satir = KS_SatirKopya(aMalz, idx)
    End If
    satir(1, M_KOD) = kod
    satir(1, M_AD) = KS_Metin(g(1))
    satir(1, M_KAT) = KS_Metin(g(2))
    satir(1, M_BIRIM) = KS_Metin(g(3))
    satir(1, M_URETICI) = KS_Metin(g(4))
    satir(1, M_FIYAT) = fiyat
    satir(1, M_GARANTI) = CLng(gar)
    satir(1, M_NOT) = KS_Metin(g(7))
    KS_MalzemeHazirla = True
End Function

' g: Sevk�i, Sevk Yeri, Malzeme Kodu, Adet, Birim Fiyat, Planlanan, Ger�ek Geli�, �rsaliye, Seri, Not
Public Function KS_SevkHazirla(ByVal g As Variant, ByVal idx As Long, ByRef satir As Variant, _
        ByRef hata As String, ByRef uyari As String) As Boolean
    Dim mi As Long, adet As Double, fiyat As Double, plan As Date, gelis As Date, k As String, no As String
    hata = "": uyari = ""
    If Len(KS_Metin(g(0))) = 0 Then hata = "Sevk�i se�ilmeli.": Exit Function
    If Not KS_TanimKontrol(dSevkci, T_SEVKCI, KS_Metin(g(0)), "Sevk�i", hata) Then Exit Function
    If Len(KS_Metin(g(1))) = 0 Then hata = "Sevk yeri se�ilmeli.": Exit Function
    If Not KS_TanimKontrol(dYer, T_YER, KS_Metin(g(1)), "Sevk yeri", hata) Then Exit Function
    If Len(KS_Metin(g(2))) = 0 Then hata = "Malzeme kodu girilmeli.": Exit Function
    If Not dMalz.Exists(KS_Anahtar(g(2))) Then hata = "Malzeme kodu kay�tl� de�il: " & KS_Metin(g(2)) & _
        ". �nce malzemeyi tan�mlay�n.": Exit Function
    mi = dMalz(KS_Anahtar(g(2)))
    If Not KS_Sayi(g(3), adet) Then hata = "Adet / miktar say� olmal�.": Exit Function
    If adet <= 0 Then hata = "Adet / miktar s�f�rdan b�y�k olmal�.": Exit Function
    If KS_Bos(g(4)) Then
        If Not KS_Sayi(aMalz(mi, M_FIYAT), fiyat) Then hata = "Malzemenin liste fiyat� yok; birim fiyat girin.": Exit Function
    Else
        If Not KS_Sayi(g(4), fiyat) Then hata = "Birim fiyat say� olmal�.": Exit Function
        If fiyat < 0 Then hata = "Birim fiyat negatif olamaz.": Exit Function
    End If
    If Not KS_Tarih(g(5), plan) Then hata = "Planlanan teslim tarihi ge�erli de�il (gg.aa.yyyy).": Exit Function
    If Not KS_Bos(g(6)) Then
        If Not KS_Tarih(g(6), gelis) Then hata = "Ger�ek geli� tarihi ge�erli de�il (gg.aa.yyyy).": Exit Function
        If gelis > Date Then hata = "Ger�ek geli� tarihi bug�nden ileri olamaz.": Exit Function
    End If

    If idx = 0 Then
        satir = KS_BosSatir(S_KOLON)
        mSevkSayac = mSevkSayac + 1
        no = KS_NoBicim("SVK-", mSevkSayac)
        satir(1, S_NO) = no
        satir(1, S_ZAMAN) = Now
        satir(1, S_KULL) = KS_Kullanici()
        satir(1, S_GARAY) = aMalz(mi, M_GARANTI)
    Else
        satir = KS_SatirKopya(aSevk, idx)
        no = KS_Metin(satir(1, S_NO))
        ' Garanti s�resi sevk an�ndaki s�zle�meden gelir; yaln�z malzeme de�i�irse yenilenir.
        If KS_Anahtar(satir(1, S_KOD)) <> KS_Anahtar(g(2)) Then satir(1, S_GARAY) = aMalz(mi, M_GARANTI)
    End If
    satir(1, S_SEVKCI) = KS_Metin(g(0))
    satir(1, S_YER) = KS_Metin(g(1))
    satir(1, S_KOD) = KS_Metin(aMalz(mi, M_KOD))
    satir(1, S_AD) = aMalz(mi, M_AD)
    satir(1, S_ADET) = adet
    satir(1, S_FIYAT) = fiyat
    satir(1, S_PLAN) = plan
    If KS_Bos(g(6)) Then satir(1, S_GELIS) = Empty Else satir(1, S_GELIS) = gelis
    satir(1, S_IRS) = KS_Metin(g(7))
    satir(1, S_SERI) = KS_Metin(g(8))
    satir(1, S_NOT) = KS_Metin(g(9))
    KS_SevkHesapla satir, 1

    k = KS_Anahtar(g(7))
    If Len(k) > 0 Then
        k = k & "|" & KS_Anahtar(g(2))
        If dIrs.Exists(k) Then
            If dIrs(k) <> no Then uyari = "Ayn� irsaliye ve malzeme ile kay�t var: " & dIrs(k)
        Else
            dIrs(k) = no
        End If
    End If
    KS_SevkHazirla = True
End Function

' g: Sevk No, Seri No, Ar�za Tarihi, Adet, Tip, A��klama, Bildirim, D�n��, ��z�m, ��z�m �ekli,
'    Tamir Maliyeti, Kar��layan, Not
Public Function KS_ArizaHazirla(ByVal g As Variant, ByVal idx As Long, ByVal mevcut As Variant, _
        ByRef satir As Variant, ByRef hata As String) As Boolean
    Dim si As Long, mi As Long, t As Date, gelis As Date, bil As Date, don As Date, coz As Date
    Dim adet As Double, sevkAdet As Double, maliyet As Double, hb As Boolean
    hata = ""
    If Len(KS_Metin(g(0))) = 0 Then hata = "Sevk no se�ilmeli.": Exit Function
    If Not dSevk.Exists(KS_Anahtar(g(0))) Then hata = "Sevk no bulunamad�: " & KS_Metin(g(0)): Exit Function
    si = dSevk(KS_Anahtar(g(0)))
    If Not KS_Tarih(g(2), t) Then hata = "Ar�za tarihi ge�erli de�il (gg.aa.yyyy).": Exit Function
    If t > Date Then hata = "Ar�za tarihi bug�nden ileri olamaz.": Exit Function
    If KS_Tarih(aSevk(si, S_GELIS), gelis) Then
        If t < gelis Then hata = "Ar�za tarihi, malzemenin geli� tarihinden (" & _
            Format$(gelis, "dd.mm.yyyy") & ") �nce olamaz.": Exit Function
    End If
    If Not KS_Sayi(g(3), adet) Then hata = "Ar�zal� adet say� olmal�.": Exit Function
    If adet <= 0 Then hata = "Ar�zal� adet s�f�rdan b�y�k olmal�.": Exit Function
    If KS_Sayi(aSevk(si, S_ADET), sevkAdet) Then
        If adet > sevkAdet Then hata = "Ar�zal� adet (" & adet & "), sevk edilen miktar� (" & sevkAdet & ") a�amaz.": Exit Function
    End If
    If Not KS_Bos(g(6)) Then
        If Not KS_Tarih(g(6), bil) Then hata = "�reticiye bildirim tarihi ge�erli de�il.": Exit Function
        If bil < t Then hata = "Bildirim tarihi ar�za tarihinden �nce olamaz.": Exit Function
        If bil > Date Then hata = "Bildirim tarihi bug�nden ileri olamaz.": Exit Function
        hb = True
    End If
    If Not KS_Bos(g(7)) Then
        If Not hb Then hata = "�retici d�n�� tarihi i�in �nce bildirim tarihi girilmeli.": Exit Function
        If Not KS_Tarih(g(7), don) Then hata = "�retici d�n�� tarihi ge�erli de�il.": Exit Function
        If don < bil Then hata = "D�n�� tarihi bildirim tarihinden �nce olamaz.": Exit Function
        If don > Date Then hata = "D�n�� tarihi bug�nden ileri olamaz.": Exit Function
    End If
    If Not KS_Bos(g(8)) Then
        If Not KS_Tarih(g(8), coz) Then hata = "��z�m tarihi ge�erli de�il.": Exit Function
        If coz < t Then hata = "��z�m tarihi ar�za tarihinden �nce olamaz.": Exit Function
        If coz > Date Then hata = "��z�m tarihi bug�nden ileri olamaz.": Exit Function
    End If
    If Not KS_Bos(g(10)) Then
        If Not KS_Sayi(g(10), maliyet) Then hata = "Tamir maliyeti say� olmal�.": Exit Function
        If maliyet < 0 Then hata = "Tamir maliyeti negatif olamaz.": Exit Function
    End If

    If idx = 0 Then
        satir = KS_BosSatir(A_KOLON)
        mArizaSayac = mArizaSayac + 1
        satir(1, A_NO) = KS_NoBicim("ARZ-", mArizaSayac)
        satir(1, A_ZAMAN) = Now
        satir(1, A_KULL) = KS_Kullanici()
    Else
        satir = mevcut
    End If
    satir(1, A_SEVK) = KS_Metin(aSevk(si, S_NO))
    satir(1, A_SERI) = KS_Metin(g(1))
    satir(1, A_KOD) = aSevk(si, S_KOD)
    satir(1, A_AD) = aSevk(si, S_AD)
    satir(1, A_SEVKCI) = aSevk(si, S_SEVKCI)
    satir(1, A_YER) = aSevk(si, S_YER)
    satir(1, A_GARBIT) = aSevk(si, S_GARBIT)
    If dMalz.Exists(KS_Anahtar(aSevk(si, S_KOD))) Then
        mi = dMalz(KS_Anahtar(aSevk(si, S_KOD)))
        If mi > 0 Then satir(1, A_URETICI) = aMalz(mi, M_URETICI)
    End If
    satir(1, A_TARIH) = t
    satir(1, A_ADET) = adet
    satir(1, A_TIP) = KS_Metin(g(4))
    satir(1, A_ACIK) = KS_Metin(g(5))
    If KS_Bos(g(6)) Then satir(1, A_BILDIRIM) = Empty Else satir(1, A_BILDIRIM) = bil
    If KS_Bos(g(7)) Then satir(1, A_DONUS) = Empty Else satir(1, A_DONUS) = don
    If KS_Bos(g(8)) Then satir(1, A_COZUM) = Empty Else satir(1, A_COZUM) = coz
    satir(1, A_SEKIL) = KS_Metin(g(9))
    If KS_Bos(g(10)) Then satir(1, A_MALIYET) = Empty Else satir(1, A_MALIYET) = maliyet
    satir(1, A_KARS) = KS_Metin(g(11))
    satir(1, A_NOT) = KS_Metin(g(12))
    KS_ArizaHesapla satir, 1
    KS_ArizaHazirla = True
End Function

' ================================================================ form d�zeni

Private Function KS_MalzemeAlanlari() As Variant
    KS_MalzemeAlanlari = Array( _
        Array("Malzeme Kodu", "fM_KOD", "kod", True, ""), _
        Array("Malzeme Ad�", "fM_AD", "metin", True, ""), _
        Array("Kategori", "fM_KAT", "listeS", False, "lstKategori"), _
        Array("Birim", "fM_BIRIM", "listeS", False, "lstBirim"), _
        Array("�retici", "fM_URETICI", "listeS", False, "lstSevkci"), _
        Array("Birim Fiyat (TL)", "fM_FIYAT", "para", True, ""), _
        Array("Garanti S�resi (Ay)", "fM_GARANTI", "sayi", True, ""), _
        Array("Not", "fM_NOT", "metin", False, ""))
End Function

Private Function KS_SevkAlanlari() As Variant
    Dim m As String
    m = "MATCH(fS_KOD,INDEX(" & T_MALZ & ",0,1),0)"
    KS_SevkAlanlari = Array( _
        Array("Sevk No  (g�ncellemede)", "fS_NO", "kod", False, ""), _
        Array("Sevk�i", "fS_SEVKCI", "liste", True, "lstSevkci"), _
        Array("Sevk Yeri", "fS_YER", "liste", True, "lstYer"), _
        Array("Malzeme Kodu", "fS_KOD", "listeK", True, "lstMalzeme"), _
        Array("� Malzeme", "fS_OTO", "oto", False, _
            "=IFERROR(INDEX(" & T_MALZ & "," & m & "," & M_AD & ")&""   |   Garanti ""&INDEX(" & T_MALZ & _
            "," & m & "," & M_GARANTI & ")&"" ay"","""")"), _
        Array("� Liste Fiyat�", "fS_LFIYAT", "otoPara", False, _
            "=IFERROR(INDEX(" & T_MALZ & "," & m & "," & M_FIYAT & "),"""")"), _
        Array("Adet / Miktar", "fS_ADET", "sayi", True, ""), _
        Array("Birim Fiyat (bo� = liste)", "fS_FIYAT", "para", False, ""), _
        Array("Planlanan Teslim Tarihi", "fS_PLAN", "tarih", True, ""), _
        Array("Ger�ek Geli� Tarihi", "fS_GELIS", "tarih", False, ""), _
        Array("�rsaliye / Belge No", "fS_IRS", "kod", False, ""), _
        Array("Seri / Lot No", "fS_SERI", "kod", False, ""), _
        Array("Not", "fS_NOT", "metin", False, ""))
End Function

Private Function KS_ArizaAlanlari() As Variant
    Dim m As String
    m = "MATCH(fA_SEVK,INDEX(" & T_SEVK & ",0,1),0)"
    KS_ArizaAlanlari = Array( _
        Array("Ar�za No  (g�ncellemede)", "fA_NO", "kod", False, ""), _
        Array("Sevk No", "fA_SEVK", "listeK", True, "lstSevk"), _
        Array("� Malzeme", "fA_OTO1", "oto", False, _
            "=IFERROR(INDEX(" & T_SEVK & "," & m & "," & S_KOD & ")&""  -  ""&INDEX(" & T_SEVK & "," & m & "," & S_AD & "),"""")"), _
        Array("� Sevk Yeri / Sevk�i", "fA_OTO2", "oto", False, _
            "=IFERROR(INDEX(" & T_SEVK & "," & m & "," & S_YER & ")&""  /  ""&INDEX(" & T_SEVK & "," & m & "," & S_SEVKCI & "),"""")"), _
        Array("� Garanti Biti�", "fA_GARBIT", "otoTarih", False, _
            "=IFERROR(IF(INDEX(" & T_SEVK & "," & m & "," & S_GARBIT & ")="""",""Geli� tarihi yok"",INDEX(" & T_SEVK & "," & m & "," & S_GARBIT & ")),"""")"), _
        Array("Seri No (varsa)", "fA_SERI", "kod", False, ""), _
        Array("Ar�za Tarihi", "fA_TARIH", "tarih", True, ""), _
        Array("� Garanti Durumu", "fA_KAPSAM", "oto", False, _
            "=IF(OR(fA_TARIH="""",NOT(ISNUMBER(fA_GARBIT))),"""",IF(fA_TARIH<=fA_GARBIT,""GARANT� KAPSAMINDA"",""GARANT� DI�I""))"), _
        Array("Ar�zal� Adet", "fA_ADET", "sayi", True, ""), _
        Array("Ar�za Tipi", "fA_TIP", "listeS", False, "lstTip"), _
        Array("Ar�za A��klamas�", "fA_ACIK", "metin", False, ""), _
        Array("�reticiye Bildirim Tarihi", "fA_BILDIRIM", "tarih", False, ""), _
        Array("�retici D�n�� Tarihi", "fA_DONUS", "tarih", False, ""), _
        Array("��z�m Tarihi", "fA_COZUM", "tarih", False, ""), _
        Array("��z�m �ekli", "fA_SEKIL", "listeS", False, "lstCozum"), _
        Array("Tamir Maliyeti (TL)", "fA_MALIYET", "para", False, ""), _
        Array("Maliyeti Kar��layan", "fA_KARS", "listeS", False, "lstKarsilayan"), _
        Array("Not", "fA_NOT", "metin", False, ""))
End Function

Public Sub KS_KayitFormKur()
    Dim ws As Worksheet
    Set ws = KS_WS(SH_KAYIT)
    KS_SayfaSifirla ws
    ws.Columns("B").ColumnWidth = 23
    ws.Columns("C").ColumnWidth = 30
    ws.Columns("D").ColumnWidth = 3
    ws.Columns("E").ColumnWidth = 23
    ws.Columns("F").ColumnWidth = 34
    ws.Columns("G").ColumnWidth = 3
    ws.Columns("H").ColumnWidth = 24
    ws.Columns("I").ColumnWidth = 34
    ws.Columns("J").ColumnWidth = 3
    KS_Bant ws, 10, "KAYIT MERKEZ�", _
        "S�rayla: 1 Malzeme > 2 Sevkiyat > 3 Ar�za.  * zorunlu   � otomatik   GET�R: numarayla kayd� forma �a��r�r."
    KS_FormKart ws, 2, "01   MALZEME TANIMI", "Ana kay�t: kod, fiyat, garanti s�resi", KS_MalzemeAlanlari(), _
        Array("KAYDET", "KS_MALZEME_KAYDET", "G�NCELLE", "KS_MALZEME_GUNCELLE", "GET�R", "KS_MALZEME_GETIR", _
            "TEM�ZLE", "KS_MALZEME_TEMIZLE"), "kM"
    KS_FormKart ws, 5, "02   SEVK�YAT KAYDI", "Hangi sevk�i, nereye, ne zaman, ka� adet", KS_SevkAlanlari(), _
        Array("KAYDET", "KS_SEVK_KAYDET", "G�NCELLE", "KS_SEVK_GUNCELLE", "GET�R", "KS_SEVK_GETIR", _
            "TEM�ZLE", "KS_SEVK_TEMIZLE"), "kS"
    KS_FormKart ws, 8, "03   ARIZA KAYDI", "Garanti kapsam� ve �retici d�n��� otomatik izlenir", KS_ArizaAlanlari(), _
        Array("KAYDET", "KS_ARIZA_KAYDET", "G�NCELLE", "KS_ARIZA_GUNCELLE", "GET�R", "KS_ARIZA_GETIR", _
            "TEM�ZLE", "KS_ARIZA_TEMIZLE"), "kA"
    KS_KapsamRenk ws
    KS_Pencere ws, 90, 0, False
    ws.Range("C" & ALAN_ILK).Select
End Sub

Private Sub KS_FormKart(ByVal ws As Worksheet, ByVal kol As Long, ByVal baslik As String, _
        ByVal alt As String, ByVal alanlar As Variant, ByVal butonlar As Variant, ByVal onek As String)
    Dim i As Long, r As Long, e As Range, v As Range, a As Variant, kart As Range
    Dim sol As Double, gen As Double, ust As Double, b As Long

    Set kart = ws.Range(ws.Cells(KART_UST, kol), ws.Cells(BUTON_SATIR + 2, kol + 1))
    kart.Interior.Color = C_KART()
    With kart
        .Borders(xlEdgeLeft).Color = C_CIZGI()
        .Borders(xlEdgeRight).Color = C_CIZGI()
        .Borders(xlEdgeBottom).Color = C_CIZGI()
    End With
    With ws.Range(ws.Cells(KART_UST, kol), ws.Cells(KART_UST, kol + 1))
        .Interior.Color = C_LAC()
        .Borders(xlEdgeTop).Color = C_CAMGOBEGI()
        .Borders(xlEdgeTop).Weight = xlThick
    End With
    ws.Rows(KART_UST).RowHeight = 28
    With ws.Cells(KART_UST, kol)
        .Value = baslik
        .Font.Color = vbWhite
        .Font.Bold = True
        .Font.Size = 11
        .IndentLevel = 1
    End With
    With ws.Cells(KART_UST + 1, kol)
        .Value = alt
        .Font.Size = 8
        .Font.Italic = True
        .Font.Color = C_GRI()
        .IndentLevel = 1
    End With
    ws.Rows(KART_UST + 1).RowHeight = 20

    For i = 0 To UBound(alanlar)
        a = alanlar(i)
        r = ALAN_ILK + i
        ws.Rows(r).RowHeight = 21
        Set e = ws.Cells(r, kol)
        Set v = ws.Cells(r, kol + 1)
        e.Value = a(0) & IIf(a(3), "  *", "")
        e.Font.Size = 9
        e.IndentLevel = 1
        If Left$(a(2), 3) = "oto" Then
            e.Font.Color = C_TURKUAZ()
            e.Font.Italic = True
        Else
            e.Font.Color = C_METIN()
        End If
        If a(3) Then e.Characters(Len(e.Value) - 0, 1).Font.Color = C_CAMGOBEGI()
        KS_AdHucre CStr(a(1)), v
        With v
            .Font.Size = 10
            .HorizontalAlignment = xlLeft
            .IndentLevel = 1
            .Borders(xlEdgeBottom).Color = C_CIZGI()
        End With
        Select Case a(2)
            Case "oto", "otoPara", "otoTarih"
                v.Interior.Color = C_OTO()
                v.Font.Color = C_TURKUAZ()
                v.Font.Bold = True
                v.Locked = True
                If a(2) = "otoPara" Then v.NumberFormat = KS_FmtTL()
                If a(2) = "otoTarih" Then v.NumberFormat = KS_FmtTarih()
                v.Formula = a(4)
            Case Else
                v.Interior.Color = C_GIRIS()
                v.Font.Color = C_LAC()
                v.Locked = False
                v.Borders(xlEdgeBottom).Color = C_CAMGOBEGI()
                Select Case a(2)
                    Case "kod", "metin": v.NumberFormat = "@"
                    Case "liste": v.NumberFormat = "@": KS_Liste v, CStr(a(4)), True
                    Case "listeK": v.NumberFormat = "@": KS_Liste v, CStr(a(4)), True
                    Case "listeS": v.NumberFormat = "@": KS_Liste v, CStr(a(4)), False
                    Case "para": v.NumberFormat = KS_FmtTL(): KS_SayiDogrulama v
                    Case "sayi": v.NumberFormat = "General": KS_SayiDogrulama v
                    Case "tarih": v.NumberFormat = KS_FmtTarih(): KS_TarihDogrulama v
                End Select
        End Select
    Next i

    ' Butonlar: kart�n alt�nda e�it aral�kl� d�rt d��me.
    sol = ws.Cells(BUTON_SATIR, kol).Left + 6
    gen = (ws.Cells(BUTON_SATIR, kol + 2).Left - ws.Cells(BUTON_SATIR, kol).Left - 12 - 3 * 5) / 4
    ust = ws.Cells(BUTON_SATIR, kol).Top + 2
    ws.Rows(BUTON_SATIR).RowHeight = 28
    For b = 0 To 3
        KS_Buton ws, onek & "_btn" & b, CStr(butonlar(b * 2)), sol + b * (gen + 5), ust, gen, 24, _
            CStr(butonlar(b * 2 + 1)), Choose(b + 1, "ana", "koyu", "cizgi", "gri")
    Next b
End Sub

Private Sub KS_KapsamRenk(ByVal ws As Worksheet)
    Dim r As Range, fc As Object
    Set r = KS_F("fA_KAPSAM")
    r.FormatConditions.Delete
    Set fc = r.FormatConditions.Add(Type:=xlTextString, String:="GARANT� KAPSAMINDA", TextOperator:=xlBeginsWith)
    fc.Font.Color = C_YESIL()
    fc.Interior.Color = RGB(220, 245, 232)
    Set fc = r.FormatConditions.Add(Type:=xlTextString, String:="GARANT� DI�I", TextOperator:=xlBeginsWith)
    fc.Font.Color = C_KIRMIZI()
    fc.Interior.Color = RGB(253, 226, 228)
End Sub

' ================================================================ form yard�mc�lar�

Private Sub KS_Temizle(ByVal adlar As Variant)
    Dim a As Variant
    For Each a In adlar
        KS_F(CStr(a)).ClearContents
    Next a
End Sub

Private Function KS_Degerler(ByVal adlar As Variant) As Variant
    Dim v() As Variant, i As Long
    ReDim v(0 To UBound(adlar))
    For i = 0 To UBound(adlar)
        v(i) = KS_FV(CStr(adlar(i)))
    Next i
    KS_Degerler = v
End Function

Private Sub KS_Doldur(ByVal adlar As Variant, ByVal degerler As Variant)
    Dim i As Long
    For i = 0 To UBound(adlar)
        KS_F(CStr(adlar(i))).Value = degerler(i)
    Next i
End Sub

Private Function KS_AlanM() As Variant
    KS_AlanM = Array("fM_KOD", "fM_AD", "fM_KAT", "fM_BIRIM", "fM_URETICI", "fM_FIYAT", "fM_GARANTI", "fM_NOT")
End Function

Private Function KS_AlanS() As Variant
    KS_AlanS = Array("fS_SEVKCI", "fS_YER", "fS_KOD", "fS_ADET", "fS_FIYAT", "fS_PLAN", "fS_GELIS", _
        "fS_IRS", "fS_SERI", "fS_NOT")
End Function

Private Function KS_AlanA() As Variant
    KS_AlanA = Array("fA_SEVK", "fA_SERI", "fA_TARIH", "fA_ADET", "fA_TIP", "fA_ACIK", "fA_BILDIRIM", _
        "fA_DONUS", "fA_COZUM", "fA_SEKIL", "fA_MALIYET", "fA_KARS", "fA_NOT")
End Function

' Ortak kay�t yazma: veriyi yazar, t�m�n� yeniden hesaplar, g�nl��e i�ler.
Private Sub KS_Yaz(ByVal tablo As String, ByVal idx As Long, ByVal satir As Variant, _
        ByVal islem As String, ByVal no As String, ByVal detay As String)
    Dim lo As ListObject
    Set lo = KS_LOZ(tablo)
    KS_Basla
    KS_Ac lo.Parent
    KS_SatirYaz lo, idx, satir
    KS_Kapat lo.Parent
    KS_HesaplaTumu
    KS_Bitir
    KS_Log islem, no, detay
End Sub

Private Sub KS_HataGoster(ByVal baslik As String)
    Dim no As Long, ac As String
    no = Err.Number: ac = Err.Description
    KS_Bitir True
    MsgBox baslik & vbCrLf & "Hata: " & no & " / " & ac, vbExclamation, KS_AD
End Sub

' ================================================================ MALZEME

Public Sub KS_MALZEME_KAYDET()
    KS_MalzemeIslem False
End Sub
Public Sub KS_MALZEME_GUNCELLE()
    KS_MalzemeIslem True
End Sub

Private Sub KS_MalzemeIslem(ByVal guncelle As Boolean)
    Dim g As Variant, satir As Variant, hata As String, idx As Long
    On Error GoTo Hata
    KS_BaglamYukle
    g = KS_Degerler(KS_AlanM())
    If guncelle Then
        If dMalz.Exists(KS_Anahtar(g(0))) Then idx = dMalz(KS_Anahtar(g(0)))
        If idx = 0 Then
            MsgBox "G�ncellenecek malzeme bulunamad�. Kodu yaz�p �nce GET�R'e bas�n.", vbExclamation, KS_AD
            Exit Sub
        End If
    End If
    If Not KS_MalzemeHazirla(g, idx, satir, hata) Then
        MsgBox hata, vbExclamation, KS_AD
        Exit Sub
    End If
    If guncelle Then
        If MsgBox(KS_Metin(g(0)) & " g�ncellensin mi?" & vbCrLf & vbCrLf & _
            "Not: Garanti s�resi de�i�ikli�i yaln�z bundan sonraki sevkiyatlara uygulan�r.", _
            vbQuestion + vbYesNo, KS_AD) <> vbYes Then Exit Sub
    End If
    KS_Yaz T_MALZ, idx, satir, IIf(guncelle, "MALZEME G�NCELLE", "MALZEME EKLE"), _
        KS_Metin(satir(1, M_KOD)), KS_Metin(satir(1, M_AD))
    KS_Temizle KS_AlanM()
    MsgBox "Malzeme " & IIf(guncelle, "g�ncellendi: ", "kaydedildi: ") & KS_Metin(satir(1, M_KOD)), vbInformation, KS_AD
    Exit Sub
Hata:
    KS_HataGoster "Malzeme kaydedilemedi."
End Sub

Public Sub KS_MALZEME_GETIR()
    Dim idx As Long, k As Variant
    On Error GoTo Hata
    KS_BaglamYukle
    k = KS_FV("fM_KOD")
    If dMalz.Exists(KS_Anahtar(k)) Then idx = dMalz(KS_Anahtar(k))
    If idx = 0 Then
        MsgBox "Malzeme kodu bulunamad�: " & KS_Metin(k), vbExclamation, KS_AD
        Exit Sub
    End If
    KS_Doldur KS_AlanM(), Array(aMalz(idx, M_KOD), aMalz(idx, M_AD), aMalz(idx, M_KAT), aMalz(idx, M_BIRIM), _
        aMalz(idx, M_URETICI), aMalz(idx, M_FIYAT), aMalz(idx, M_GARANTI), aMalz(idx, M_NOT))
    Exit Sub
Hata:
    KS_HataGoster "Malzeme getirilemedi."
End Sub

Public Sub KS_MALZEME_TEMIZLE()
    KS_Temizle KS_AlanM()
End Sub

' ================================================================ SEVK�YAT

Public Sub KS_SEVK_KAYDET()
    KS_SevkIslem False
End Sub
Public Sub KS_SEVK_GUNCELLE()
    KS_SevkIslem True
End Sub

Private Sub KS_SevkIslem(ByVal guncelle As Boolean)
    Dim g As Variant, satir As Variant, hata As String, uyari As String, idx As Long, no As Variant
    On Error GoTo Hata
    KS_BaglamYukle
    g = KS_Degerler(KS_AlanS())
    If guncelle Then
        no = KS_FV("fS_NO")
        If dSevk.Exists(KS_Anahtar(no)) Then idx = dSevk(KS_Anahtar(no))
        If idx = 0 Then
            MsgBox "G�ncellenecek sevk no bulunamad�. Sevk no yaz�p �nce GET�R'e bas�n.", vbExclamation, KS_AD
            Exit Sub
        End If
    End If
    If Not KS_SevkHazirla(g, idx, satir, hata, uyari) Then
        MsgBox hata, vbExclamation, KS_AD
        Exit Sub
    End If
    If Len(uyari) > 0 Then
        If MsgBox(uyari & vbCrLf & vbCrLf & "Yine de kaydedilsin mi?", vbExclamation + vbYesNo, KS_AD) <> vbYes Then Exit Sub
    End If
    If guncelle Then
        If MsgBox(KS_Metin(satir(1, S_NO)) & " g�ncellensin mi?", vbQuestion + vbYesNo, KS_AD) <> vbYes Then Exit Sub
    End If
    KS_Yaz T_SEVK, idx, satir, IIf(guncelle, "SEVK G�NCELLE", "SEVK EKLE"), KS_Metin(satir(1, S_NO)), _
        KS_Metin(satir(1, S_KOD)) & " x " & satir(1, S_ADET) & " > " & KS_Metin(satir(1, S_YER))
    KS_Temizle KS_AlanS()
    KS_F("fS_NO").ClearContents
    MsgBox "Sevkiyat " & IIf(guncelle, "g�ncellendi: ", "kaydedildi: ") & KS_Metin(satir(1, S_NO)) & vbCrLf & _
        "Garanti: " & KS_Metin(satir(1, S_GDURUM)), vbInformation, KS_AD
    Exit Sub
Hata:
    KS_HataGoster "Sevkiyat kaydedilemedi."
End Sub

Public Sub KS_SEVK_GETIR()
    Dim idx As Long, k As Variant
    On Error GoTo Hata
    KS_BaglamYukle
    k = KS_FV("fS_NO")
    If dSevk.Exists(KS_Anahtar(k)) Then idx = dSevk(KS_Anahtar(k))
    If idx = 0 Then
        MsgBox "Sevk no bulunamad�: " & KS_Metin(k), vbExclamation, KS_AD
        Exit Sub
    End If
    KS_Doldur KS_AlanS(), Array(aSevk(idx, S_SEVKCI), aSevk(idx, S_YER), aSevk(idx, S_KOD), aSevk(idx, S_ADET), _
        aSevk(idx, S_FIYAT), aSevk(idx, S_PLAN), aSevk(idx, S_GELIS), aSevk(idx, S_IRS), aSevk(idx, S_SERI), _
        aSevk(idx, S_NOT))
    Exit Sub
Hata:
    KS_HataGoster "Sevkiyat getirilemedi."
End Sub

Public Sub KS_SEVK_TEMIZLE()
    KS_Temizle KS_AlanS()
    KS_F("fS_NO").ClearContents
End Sub

' ================================================================ ARIZA

Public Sub KS_ARIZA_KAYDET()
    KS_ArizaIslem False
End Sub
Public Sub KS_ARIZA_GUNCELLE()
    KS_ArizaIslem True
End Sub

Private Sub KS_ArizaIslem(ByVal guncelle As Boolean)
    Dim g As Variant, satir As Variant, hata As String, idx As Long, lo As ListObject, mevcut As Variant
    On Error GoTo Hata
    KS_BaglamYukle
    g = KS_Degerler(KS_AlanA())
    Set lo = KS_LOZ(T_ARIZA)
    If guncelle Then
        idx = KS_SatirBul(lo, A_NO, KS_FV("fA_NO"))
        If idx = 0 Then
            MsgBox "G�ncellenecek ar�za no bulunamad�. Ar�za no yaz�p �nce GET�R'e bas�n.", vbExclamation, KS_AD
            Exit Sub
        End If
        mevcut = lo.ListRows(idx).Range.Value
    End If
    If Not KS_ArizaHazirla(g, idx, mevcut, satir, hata) Then
        MsgBox hata, vbExclamation, KS_AD
        Exit Sub
    End If
    If guncelle Then
        If MsgBox(KS_Metin(satir(1, A_NO)) & " g�ncellensin mi?", vbQuestion + vbYesNo, KS_AD) <> vbYes Then Exit Sub
    End If
    KS_Yaz T_ARIZA, idx, satir, IIf(guncelle, "ARIZA G�NCELLE", "ARIZA EKLE"), KS_Metin(satir(1, A_NO)), _
        KS_Metin(satir(1, A_SEVK)) & " / " & KS_Metin(satir(1, A_KOD)) & " / " & KS_Metin(satir(1, A_DURUM))
    KS_Temizle KS_AlanA()
    KS_F("fA_NO").ClearContents
    MsgBox "Ar�za " & IIf(guncelle, "g�ncellendi: ", "kaydedildi: ") & KS_Metin(satir(1, A_NO)) & vbCrLf & _
        "Garanti kapsam�: " & KS_Metin(satir(1, A_KAPSAM)) & "   |   Durum: " & KS_Metin(satir(1, A_DURUM)), _
        vbInformation, KS_AD
    Exit Sub
Hata:
    KS_HataGoster "Ar�za kaydedilemedi."
End Sub

Public Sub KS_ARIZA_GETIR()
    Dim idx As Long, lo As ListObject, a As Variant
    On Error GoTo Hata
    Set lo = KS_LOZ(T_ARIZA)
    idx = KS_SatirBul(lo, A_NO, KS_FV("fA_NO"))
    If idx = 0 Then
        MsgBox "Ar�za no bulunamad�: " & KS_Metin(KS_FV("fA_NO")), vbExclamation, KS_AD
        Exit Sub
    End If
    a = lo.ListRows(idx).Range.Value
    KS_Doldur KS_AlanA(), Array(a(1, A_SEVK), a(1, A_SERI), a(1, A_TARIH), a(1, A_ADET), a(1, A_TIP), _
        a(1, A_ACIK), a(1, A_BILDIRIM), a(1, A_DONUS), a(1, A_COZUM), a(1, A_SEKIL), a(1, A_MALIYET), _
        a(1, A_KARS), a(1, A_NOT))
    Exit Sub
Hata:
    KS_HataGoster "Ar�za getirilemedi."
End Sub

Public Sub KS_ARIZA_TEMIZLE()
    KS_Temizle KS_AlanA()
    KS_F("fA_NO").ClearContents
End Sub
