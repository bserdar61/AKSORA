Attribute VB_Name = "modKS_SAP"
Option Explicit

' SAP sat�nalma listesi (ME2N benzeri, "TEDAR�K�� �S�M.xlsx" bi�imi) aktar�m�.
' Yaln�z TANIMLAR'daki sevk yerlerine (�EDA� �retim yerleri) ait, ba�lang�� tarihinden sonraki kalemler al�n�r.
' Ayn� SAS belgesi + kalem + malzeme ikinci kez aktar�lmaz; aktar�m tekrar �al��t�r�labilir.
' SAP listesinde mal giri� tarihi yoktur: ger�ek geli� tarihi KAYIT ekran�ndan ya da soruldu�unda
' (yakla��k olarak) SAP teslimat tarihinden doldurulur.

Private Function KS_Norm(ByVal v As Variant) As String
    If IsError(v) Or IsEmpty(v) Then Exit Function
    KS_Norm = UCase$(Application.WorksheetFunction.Trim(CStr(v)))
End Function

Private Function KS_SapKolon(ByVal baslik As Variant, ByVal ad As String) As Long
    Dim j As Long
    For j = LBound(baslik, 2) To UBound(baslik, 2)
        If KS_Norm(baslik(1, j)) = KS_Norm(ad) Then
            KS_SapKolon = j
            Exit Function
        End If
    Next j
End Function

Public Sub KS_SAP_AKTAR()
    Dim dosya As Variant, wb As Workbook, ws As Worksheet, v As Variant, bas As Variant, adim As String
    Dim cT As Long, cM As Long, cK As Long, cMik As Long, cGir As Long, cBr As Long, cYer As Long
    Dim cBel As Long, cKal As Long, cSat As Long, cFiy As Long, cPb As Long, cSil As Long
    Dim baslangic As Date, d As Date, s As String, i As Long, j As Long, gelisSor As VbMsgBoxResult
    Dim dYer As Object, dYeniM As Object, mSat() As Variant, mN As Long, sSat() As Variant, sN As Long
    Dim g(0 To 9) As Variant, satir As Variant, hata As String, uyari As String, x As Double, mik As Double
    Dim nTarih As Long, nBolge As Long, nSil As Long, nVar As Long, nHata As Long, nDoviz As Long, ilkHata As String
    Dim kod As String, pb As String, garanti As Long, korumali As Boolean, lo As ListObject
    On Error GoTo Hata

    adim = "Dosya se�imi"
    dosya = Application.GetOpenFilename("Excel Dosyalar� (*.xlsx;*.xlsm;*.xls),*.xlsx;*.xlsm;*.xls", , _
        "SAP sat�nalma listesini se�in")
    If VarType(dosya) = vbBoolean Then Exit Sub
    s = InputBox("Hangi teslimat tarihinden itibaren aktar�ls�n? (gg.aa.yyyy)", KS_AD, "01.01." & Year(Date))
    If Len(s) = 0 Then Exit Sub
    If Not KS_Tarih(s, baslangic) Then
        MsgBox "Tarih anla��lamad�: " & s, vbExclamation, KS_AD
        Exit Sub
    End If
    gelisSor = MsgBox("SAP listesinde mal giri� (ger�ek geli�) tarihi bulunmaz." & vbCrLf & vbCrLf & _
        "Girilen miktar� sipari� miktar�na ula�m�� ve teslimat tarihi ge�mi� kalemlerde, geli� tarihi olarak " & _
        "SAP teslimat tarihi yaz�ls�n m�?" & vbCrLf & vbCrLf & _
        "EVET: garanti hemen i�ler, ba�lang�� yakla��kt�r (notta belirtilir)." & vbCrLf & _
        "HAYIR: geli� tarihi bo� kal�r, KAYIT ekran�ndan girersiniz.", vbQuestion + vbYesNoCancel, KS_AD)
    If gelisSor = vbCancel Then Exit Sub

    adim = "Yedek"
    KS_YedekKopya "SAP_ONCESI"
    KS_Basla
    garanti = CLng(KS_ParamSayi("pSapGaranti", 24))
    Set dYer = KS_Sozluk(T_YER)
    Set dYeniM = CreateObject("Scripting.Dictionary")
    adim = "SAP dosyas�n� a�ma"
    Set wb = Workbooks.Open(Filename:=CStr(dosya), ReadOnly:=True, UpdateLinks:=0)
    KS_BaglamYukle
    KS_OtoTanimAyarla True

    ' 1. ge�i�: eksik malzemeleri topla; 2. ge�i�: sevkiyatlar� haz�rla.
    Dim gecis As Long, toplamSatir As Long, sonSatir As Long
    For Each ws In wb.Worksheets
        toplamSatir = toplamSatir + ws.UsedRange.Row + ws.UsedRange.Rows.Count
    Next ws
    ReDim mSat(1 To toplamSatir, 1 To M_KOLON)
    ReDim sSat(1 To toplamSatir, 1 To S_KOLON)
    For gecis = 1 To 2
        If gecis = 2 Then
            If mN > 0 Then
                adim = "Yeni malzemeleri yazma"
                Set lo = KS_LOZ(T_MALZ)
                KS_Ac lo.Parent
                KS_TopluEkle lo, mSat, mN
                KS_Kapat lo.Parent
            End If
            KS_BaglamYukle
            KS_OtoTanimAyarla True
        End If
        For Each ws In wb.Worksheets
            adim = "Sayfa okuma: " & ws.Name
            If Application.WorksheetFunction.CountA(ws.Rows(1)) > 3 Then
                bas = ws.Range(ws.Cells(1, 1), ws.Cells(1, ws.Cells(1, ws.Columns.Count).End(xlToLeft).Column)).Value
                cSat = KS_SapKolon(bas, "Sat�c�/teslimat yapan �rt.yeri")
                cM = KS_SapKolon(bas, "Malzeme")
                cT = KS_SapKolon(bas, "Teslimat tarihi")
                cYer = KS_SapKolon(bas, "�retim Yeri Ad�")
                If cSat > 0 And cM > 0 And cT > 0 And cYer > 0 Then
                    cK = KS_SapKolon(bas, "K�sa metin")
                    cMik = KS_SapKolon(bas, "Miktar (depo �B)")
                    cGir = KS_SapKolon(bas, "Girilen miktar")
                    cBr = KS_SapKolon(bas, "SAS �l�� birimi")
                    cBel = KS_SapKolon(bas, "Sat�nalma belgesi")
                    cKal = KS_SapKolon(bas, "Kalem")
                    cFiy = KS_SapKolon(bas, "Net fiyat")
                    cPb = KS_SapKolon(bas, "Para birimi")
                    cSil = KS_SapKolon(bas, "Silme g�stergesi")
                    sonSatir = ws.UsedRange.Row + ws.UsedRange.Rows.Count - 1
                    If sonSatir < 2 Then sonSatir = 2
                    v = ws.Range(ws.Cells(1, 1), ws.Cells(sonSatir, UBound(bas, 2))).Value
                    For i = 2 To UBound(v, 1)
                        If KS_SapSatirUygun(v, i, cT, cYer, cSil, baslangic, dYer, gecis = 2, nTarih, nBolge, nSil) Then
                            kod = KS_Metin(v(i, cM))
                            pb = UCase$(KS_Metin(v(i, cPb)))
                            If gecis = 1 Then
                                If Not KS_MalzemeVar(kod) And Not dYeniM.Exists(KS_Anahtar(kod)) And Len(kod) > 0 Then
                                    mN = mN + 1
                                    dYeniM(KS_Anahtar(kod)) = mN
                                    mSat(mN, M_KOD) = kod
                                    mSat(mN, M_AD) = KS_Metin(v(i, cK))
                                    If cBr > 0 Then mSat(mN, M_BIRIM) = KS_Metin(v(i, cBr))
                                    If pb = "TRY" And cFiy > 0 Then mSat(mN, M_FIYAT) = v(i, cFiy) Else mSat(mN, M_FIYAT) = 0
                                    mSat(mN, M_GARANTI) = garanti
                                    mSat(mN, M_KAYIT) = Date
                                    mSat(mN, M_NOT) = "SAP aktar�m� - garanti s�resini ve fiyat� kontrol edin"
                                End If
                            Else
                                adim = ws.Name & " sat�r " & i
                                g(0) = Application.WorksheetFunction.Trim(CStr(v(i, cSat)))
                                g(1) = KS_Metin(v(i, cYer))
                                g(2) = kod
                                g(3) = v(i, cMik)
                                If pb = "TRY" Or pb = "" Then
                                    g(4) = v(i, cFiy)
                                Else
                                    g(4) = 0
                                    nDoviz = nDoviz + 1
                                End If
                                g(5) = v(i, cT)
                                g(6) = Empty
                                If gelisSor = vbYes And cGir > 0 Then
                                    If KS_Sayi(v(i, cGir), x) And KS_Sayi(v(i, cMik), mik) And KS_Tarih(v(i, cT), d) Then
                                        If x >= mik And mik > 0 And d <= Date Then g(6) = d
                                    End If
                                End If
                                g(7) = "SAS " & KS_Metin(v(i, cBel)) & "/" & KS_Metin(v(i, cKal))
                                g(8) = Empty
                                g(9) = "SAP | girilen " & KS_Metin(v(i, cGir)) & " / " & KS_Metin(v(i, cMik))
                                If pb <> "TRY" And pb <> "" Then g(9) = g(9) & " | fiyat " & KS_Metin(v(i, cFiy)) & " " & pb & " (TL'ye �evrilmedi)"
                                If Not IsEmpty(g(6)) Then g(9) = g(9) & " | geli� = SAP teslimat tarihi (yakla��k)"
                                If KS_SevkHazirla(g, 0, satir, hata, uyari) Then
                                    If Len(uyari) > 0 Then
                                        nVar = nVar + 1
                                        KS_SevkSayacGeri
                                    Else
                                        sN = sN + 1
                                        For j = 1 To S_KOLON
                                            sSat(sN, j) = satir(1, j)
                                        Next j
                                    End If
                                Else
                                    nHata = nHata + 1
                                    If Len(ilkHata) = 0 Then ilkHata = ws.Name & " sat�r " & i & ": " & hata
                                End If
                            End If
                        End If
                    Next i
                End If
            End If
        Next ws
    Next gecis

    adim = "Sevkiyatlar� yazma"
    wb.Close SaveChanges:=False
    Set wb = Nothing
    If sN > 0 Then
        Set lo = KS_LOZ(T_SEVK)
        KS_Ac lo.Parent
        KS_TopluEkle lo, sSat, sN
        KS_Kapat lo.Parent
    End If
    KS_OtoTanimAyarla False
    KS_HesaplaTumu
    KS_Bitir True
    KS_Log "SAP AKTAR", CStr(dosya), sN & " sevkiyat, " & mN & " yeni malzeme, " & nVar & " zaten vard�, " & nHata & " hatal�"
    MsgBox "SAP aktar�m� tamamland�." & vbCrLf & vbCrLf & _
        "Yeni sevkiyat: " & sN & vbCrLf & _
        "Yeni malzeme kart�: " & mN & "  (garanti " & garanti & " ay varsay�ld� - kontrol edin)" & vbCrLf & _
        "Daha �nce aktar�lm�� (atland�): " & nVar & vbCrLf & _
        "Ba�lang�� tarihinden �nce: " & nTarih & vbCrLf & _
        "B�lge d��� �retim yeri: " & nBolge & vbCrLf & _
        "Silme g�stergeli: " & nSil & vbCrLf & _
        "D�viz fiyatl� (TL tutar� 0 yaz�ld�): " & nDoviz & vbCrLf & _
        "Hatal�: " & nHata & IIf(Len(ilkHata) > 0, vbCrLf & "�lk hata: " & ilkHata, ""), _
        IIf(nHata > 0, vbExclamation, vbInformation), KS_AD
    Exit Sub
Hata:
    KS_OtoTanimAyarla False
    KS_Bitir True
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    MsgBox "SAP aktar�m� durdu." & vbCrLf & "Ad�m: " & adim & vbCrLf & "Hata: " & Err.Description, vbCritical, KS_AD
End Sub

Private Function KS_SapSatirUygun(ByRef v As Variant, ByVal i As Long, ByVal cT As Long, ByVal cYer As Long, _
        ByVal cSil As Long, ByVal baslangic As Date, ByVal dYer As Object, ByVal say As Boolean, _
        ByRef nTarih As Long, ByRef nBolge As Long, ByRef nSil As Long) As Boolean
    Dim d As Date
    If cSil > 0 Then
        If Len(KS_Metin(v(i, cSil))) > 0 Then
            If say Then nSil = nSil + 1
            Exit Function
        End If
    End If
    If Not KS_Tarih(v(i, cT), d) Then
        If say Then nTarih = nTarih + 1
        Exit Function
    End If
    If d < baslangic Then
        If say Then nTarih = nTarih + 1
        Exit Function
    End If
    If Not dYer.Exists(KS_Anahtar(v(i, cYer))) Then
        If say Then nBolge = nBolge + 1
        Exit Function
    End If
    KS_SapSatirUygun = True
End Function
