Attribute VB_Name = "modAKSORA_CEKIRDEK"
Option Explicit

'==========================================================
' AKSORA
' modCORE
'
' Sistemin ortak altyap�s�:
' - Excel performans y�netimi
' - G�venli ba�latma / bitirme
' - EnableEvents korumas�
' - ��lem s�resi �l��m�
' - Excel durumunu eski haline getirme
'==========================================================

Private mScreenUpdating As Boolean
Private mEnableEvents As Boolean
Private mDisplayAlerts As Boolean
Private mCalculation As XlCalculation
Private mStatusBar As Variant

Private mBaslangicZamani As Double
Private mAktifIslem As String
Private mSistemAktif As Boolean

'==========================================================
' ��LEM� G�VENL� �EK�LDE BA�LAT
'==========================================================
Public Sub CORE_ISLEM_BASLAT(Optional ByVal IslemAdi As String = "")

On Error GoTo Hata

' Zaten CORE taraf�ndan ba�lat�lm�� bir i�lem varsa
' Excel'in mevcut durumunu tekrar kaydetme.
If mSistemAktif Then Exit Sub

' Excel'in mevcut durumunu haf�zaya al
mScreenUpdating = application.ScreenUpdating
mEnableEvents = application.EnableEvents
mDisplayAlerts = application.DisplayAlerts
mCalculation = application.Calculation
mStatusBar = application.StatusBar

mAktifIslem = IslemAdi
mBaslangicZamani = Timer
mSistemAktif = True

' Performans modu
application.ScreenUpdating = False
application.EnableEvents = False
application.DisplayAlerts = False
application.Calculation = xlCalculationManual

If Len(IslemAdi) > 0 Then
    application.StatusBar = IslemAdi & " i�lemi devam ediyor..."
Else
    application.StatusBar = "��lem devam ediyor..."
End If

Exit Sub

Hata:

' Ba�latma s�ras�nda hata olu�ursa Excel'i
' g�venli varsay�lan duruma getir.
On Error Resume Next

application.ScreenUpdating = True
application.EnableEvents = True
application.DisplayAlerts = True
application.Calculation = xlCalculationAutomatic
application.StatusBar = False

mSistemAktif = False

On Error GoTo 0

MsgBox _
    "CORE sistemi ba�lat�l�rken hata olu�tu." & _
    vbCrLf & vbCrLf & _
    "Hata: " & Err.Description & _
    vbCrLf & _
    "Hata No: " & Err.Number, _
    vbCritical, _
    "AKSORA"

End Sub

'==========================================================
' ��LEM� G�VENL� �EK�LDE B�T�R
'==========================================================
Public Function CORE_ISLEM_BITIR() As Double

Dim GecenSure As Double

On Error Resume Next

If Not mSistemAktif Then
    CORE_ISLEM_BITIR = 0
    Exit Function
End If

GecenSure = CORE_GECEN_SURE()

' Excel'i i�lemden �nceki durumuna d�nd�r
If ANA_SESSIZ_MOD Then
    application.ScreenUpdating = False
Else
    application.ScreenUpdating = mScreenUpdating
End If
application.EnableEvents = mEnableEvents
application.DisplayAlerts = mDisplayAlerts
application.Calculation = mCalculation
application.StatusBar = mStatusBar

mSistemAktif = False
mAktifIslem = vbNullString

CORE_ISLEM_BITIR = GecenSure

On Error GoTo 0

End Function

'==========================================================
' AC�L DURUMDA EXCEL'� NORMALE D�ND�R
'
' VBA �al��mas� yar�da kesilirse veya olaylar kapal�
' kal�rsa Alt+F8 �zerinden bunu �al��t�rabilirsin.
'==========================================================
Public Sub CORE_EXCEL_KURTAR()

On Error Resume Next

application.ScreenUpdating = True
application.EnableEvents = True
application.DisplayAlerts = True
application.Calculation = xlCalculationAutomatic
application.StatusBar = False
application.Cursor = xlDefault

mSistemAktif = False
mAktifIslem = vbNullString

On Error GoTo 0

MsgBox _
    "Excel g�venli �al��ma durumuna getirildi." & _
    vbCrLf & vbCrLf & _
    "Ekran g�ncelleme : A�IK" & vbCrLf & _
    "Olaylar          : A�IK" & vbCrLf & _
    "Uyar�lar         : A�IK" & vbCrLf & _
    "Hesaplama        : OTOMAT�K", _
    vbInformation, _
    "AKSORA"

End Sub

'==========================================================
' GE�EN S�RE
'==========================================================
Public Function CORE_GECEN_SURE() As Double

Dim bitis As Double

If Not mSistemAktif Then
    CORE_GECEN_SURE = 0
    Exit Function
End If

bitis = Timer

' Gece 00:00 ge�i�ine kar�� koruma
If bitis >= mBaslangicZamani Then
    CORE_GECEN_SURE = bitis - mBaslangicZamani
Else
    CORE_GECEN_SURE = (86400# - mBaslangicZamani) + bitis
End If

End Function

'==========================================================
' DURUM �UBU�UNDA MESAJ G�STER
'==========================================================
Public Sub CORE_DURUM(ByVal mesaj As String)
Static sonYazim As Double
On Error Resume Next
application.StatusBar = mesaj
' Panelden baslatilan guncellemede anlik durum seritte de gorunur.
If AKSORA_PANEL_CANLI Then
    If Abs(Timer - sonYazim) >= 0.5 Then
        sonYazim = Timer
        AKSORA_PANEL_SERIT "G�ncelleniyor  �  " & mesaj
    End If
End If
On Error GoTo 0

End Sub

'==========================================================
' CORE AKT�F M�?
'==========================================================
Public Function CORE_AKTIF_MI() As Boolean

CORE_AKTIF_MI = mSistemAktif

End Function

'==========================================================
' AKT�F ��LEM ADI
'==========================================================
Public Function CORE_AKTIF_ISLEM() As String

CORE_AKTIF_ISLEM = mAktifIslem

End Function

