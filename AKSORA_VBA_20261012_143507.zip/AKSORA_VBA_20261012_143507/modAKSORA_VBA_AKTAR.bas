Attribute VB_Name = "modAKSORA_VBA_AKTAR"
Option Explicit

Public Sub AKSORA_VBA_DISARI_AKTAR()

    Dim proje As Object, bilesen As Object
    Dim fso As Object, kabuk As Object
    Dim masaustu As String, temel As String, klasor As String
    Dim uzanti As String, adim As String
    Dim adet As Long, sira As Long

    On Error GoTo Hata

    adim = "VBA projesine eri�im"
    Set proje = ThisWorkbook.VBProject

    If proje.Protection <> 0 Then
        MsgBox "VBA projesi kilitli. �nce proje kilidini a��n.", _
               vbExclamation, "AKSORA"
        Exit Sub
    End If

    ' Ba�lamadan proje eri�imini do�rula.
    adet = proje.VBComponents.Count
    adet = 0

    adim = "Masa�st�nde klas�r olu�turma"
    Set kabuk = CreateObject("WScript.Shell")
    Set fso = CreateObject("Scripting.FileSystemObject")

    masaustu = kabuk.SpecialFolders("Desktop")
    temel = fso.BuildPath(masaustu, _
            "AKSORA_VBA_" & Format$(Now, "yyyymmdd_hhnnss"))

    klasor = temel
    sira = 1

    Do While fso.FolderExists(klasor) Or fso.FileExists(klasor)
        klasor = temel & "_" & CStr(sira)
        sira = sira + 1
    Loop

    fso.CreateFolder klasor

    For Each bilesen In proje.VBComponents

        adim = "D��ar� aktarma: " & bilesen.Name

        Select Case bilesen.Type
            Case 1
                uzanti = ".bas"  ' Standart mod�l
            Case 2, 100
                uzanti = ".cls"  ' S�n�f, sayfa ve �al��ma kitab�
            Case 3
                uzanti = ".frm"  ' Kullan�c� formu
            Case Else
                Err.Raise vbObjectError + 710, , _
                    "Desteklenmeyen bile�en t�r�: " & bilesen.Type
        End Select

        bilesen.Export fso.BuildPath(klasor, _
                                    bilesen.Name & uzanti)
        adet = adet + 1

    Next bilesen

    MsgBox adet & " VBA bile�eni d��ar� aktar�ld�." & _
           vbCrLf & vbCrLf & klasor & vbCrLf & vbCrLf & _
           "Bu klas�r�n tamam�n� ZIP yap�p g�nderin.", _
           vbInformation, "AKSORA"

    Exit Sub

Hata:
    MsgBox "Aktar�m tamamlanamad�." & vbCrLf & _
           "Ad�m: " & adim & vbCrLf & _
           "Hata: " & Err.Description & vbCrLf & _
           "Aktar�lan bile�en: " & adet & vbCrLf & _
           "Klas�r: " & klasor, _
           vbExclamation, "AKSORA"

End Sub

