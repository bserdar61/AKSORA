Attribute VB_Name = "modSAP"
Option Explicit

Private mSAPDetay As Object

'==========================================================
' AKSORA
' modSAP
'
' MERKEZ� SAP BA�LANTI MOTORU
'
' Sistemler:
' CDP -> SystemName = CDP
' EPP -> SystemName = EPP
'
' Ama�:
' - SAP GUI a��k m� kontrol etmek
' - T�m a��k SAP ba�lant�lar�n� taramak
' - �stenen sistemi (CDP / EPP) �zellikle bulmak
' - Yanl�� SAP oturumunun kullan�lmas�n� engellemek
' - Kullan�c� bilgisi g�stermemek
'
' Bu mod�l �u a�amada:
' - MB52 �al��t�rmaz
' - SAP ekran�na veri yazmaz
' - Excel stok verisine dokunmaz
'==========================================================

'==========================================================
' HEDEF SAP SESSION AL
'
' �rnek:
'
' Set session = SAP_SESSION_AL("CDP", hata)
' Set session = SAP_SESSION_AL("EPP", hata)
'
' HedefSistem bo� b�rak�l�rsa kullan�labilir ilk
' SAP oturumunu d�nd�r�r.
'==========================================================
Private mCDPSession As Object
Private mEPPSession As Object

Public Sub SAP_OTURUM_ONBELLEK_TEMIZLE()
    Set mCDPSession = Nothing
    Set mEPPSession = Nothing
End Sub

Private Function SAP_ONBELLEK_GECERLI( _
    ByVal Oturum As Object, _
    ByVal BeklenenSistem As String) As Boolean

    Dim GercekSistem As String
    On Error GoTo Cikis
    If Oturum Is Nothing Then Exit Function
    GercekSistem = UCase$(Trim$(CStr(Oturum.Info.SystemName)))
    If GercekSistem <> BeklenenSistem Then Exit Function
    SAP_ONBELLEK_GECERLI = True
Cikis:
End Function

Public Function SAP_SESSION_AL( _
Optional ByVal HedefSistem As String = "", _
Optional ByRef hataMesaji As String = "") As Object

Dim SapGuiAuto As Object
Dim SAPApp As Object
Dim SAPConnection As Object
Dim SAPSession As Object

Dim BaglantiSayisi As Long
Dim OturumSayisi As Long

Dim SistemAdi As String

Dim i As Long
Dim j As Long

On Error GoTo Hata

hataMesaji = vbNullString
HedefSistem = UCase$(Trim$(HedefSistem))

' Ayn� SAP oturumunu yeniden kullan; kopmu�sa normal taramaya d�n.
Select Case HedefSistem
    Case "CDP"
        If SAP_ONBELLEK_GECERLI(mCDPSession, "CDP") Then
            Set SAP_SESSION_AL = mCDPSession
            Exit Function
        End If
        Set mCDPSession = Nothing
    Case "EPP"
        If SAP_ONBELLEK_GECERLI(mEPPSession, "EPP") Then
            Set SAP_SESSION_AL = mEPPSession
            Exit Function
        End If
        Set mEPPSession = Nothing
End Select

'======================================================
' 1. SAP GUI NESNES�N� AL
'======================================================

Set SapGuiAuto = Nothing

On Error Resume Next

Err.Clear
Set SapGuiAuto = GetObject("SAPGUI")

If Err.Number <> 0 Then
    Err.Clear
    Set SapGuiAuto = Nothing
End If

On Error GoTo Hata

If SapGuiAuto Is Nothing Then

    hataMesaji = "SAP GUI a��k de�il."

    Set SAP_SESSION_AL = Nothing
    Exit Function

End If

'======================================================
' 2. SAP SCRIPTING ENGINE
'======================================================

Set SAPApp = Nothing

On Error Resume Next

Err.Clear
Set SAPApp = SapGuiAuto.GetScriptingEngine

If Err.Number <> 0 Then

    Err.Clear
    Set SAPApp = Nothing

End If

On Error GoTo Hata

If SAPApp Is Nothing Then

    hataMesaji = _
        "SAP GUI a��k ancak Scripting Engine'e ba�lan�lamad�."

    Set SAP_SESSION_AL = Nothing
    Exit Function

End If

'======================================================
' 3. BA�LANTI SAYISINI AL
'======================================================

BaglantiSayisi = 0

On Error Resume Next

Err.Clear
BaglantiSayisi = SAPApp.Children.Count

If Err.Number <> 0 Then

    Err.Clear
    BaglantiSayisi = 0

End If

On Error GoTo Hata

If BaglantiSayisi <= 0 Then

    hataMesaji = _
        "SAP GUI a��k ancak aktif SAP ba�lant�s� bulunamad�."

    Set SAP_SESSION_AL = Nothing
    Exit Function

End If

'======================================================
' 4. T�M BA�LANTILARI VE OTURUMLARI TARA
'======================================================

For i = 0 To BaglantiSayisi - 1

    Set SAPConnection = Nothing

    On Error Resume Next

    Err.Clear

    Set SAPConnection = _
        SAPApp.Children(CLng(i))

    If Err.Number <> 0 Then

        Err.Clear
        Set SAPConnection = Nothing

    End If

    On Error GoTo Hata

    If Not SAPConnection Is Nothing Then

        OturumSayisi = 0

        On Error Resume Next

        Err.Clear
        OturumSayisi = _
            SAPConnection.Children.Count

        If Err.Number <> 0 Then

            Err.Clear
            OturumSayisi = 0

        End If

        On Error GoTo Hata

        If OturumSayisi > 0 Then

            For j = 0 To OturumSayisi - 1

                Set SAPSession = Nothing

                On Error Resume Next

                Err.Clear

                Set SAPSession = _
                    SAPConnection.Children(CLng(j))

                If Err.Number <> 0 Then

                    Err.Clear
                    Set SAPSession = Nothing

                End If

                On Error GoTo Hata

                If Not SAPSession Is Nothing Then

                    SistemAdi = vbNullString

                    On Error Resume Next

                    Err.Clear
                    SistemAdi = _
                        CStr(SAPSession.Info.SystemName)

                    If Err.Number <> 0 Then

                        Err.Clear
                        SistemAdi = vbNullString

                    End If

                    On Error GoTo Hata

                    SistemAdi = _
                        UCase$(Trim$(SistemAdi))

                    '----------------------------------
                    ' Hedef belirtilmediyse ilk
                    ' kullan�labilir Session'� d�nd�r.
                    '----------------------------------
                    If Len(HedefSistem) = 0 Then

                        Set SAP_SESSION_AL = SAPSession
                        Exit Function

                    End If

                    '----------------------------------
                    ' �stenen sistem bulundu.
                    '----------------------------------
                    If SistemAdi = HedefSistem Then

                        If HedefSistem = "CDP" Then Set mCDPSession = SAPSession
                        If HedefSistem = "EPP" Then Set mEPPSession = SAPSession
                        Set SAP_SESSION_AL = SAPSession
                        Exit Function

                    End If

                End If

            Next j

        End If

    End If

Next i

'======================================================
' 5. HEDEF BULUNAMADI
'======================================================

If Len(HedefSistem) > 0 Then

    hataMesaji = _
        HedefSistem & _
        " SAP sistemi a��k de�il veya aktif oturum bulunamad�."

Else

    hataMesaji = _
        "Kullan�labilir aktif SAP oturumu bulunamad�."

End If

Set SAP_SESSION_AL = Nothing

Exit Function

Hata:

hataMesaji = _
    "SAP ba�lant�s� kontrol edilirken hata olu�tu." & _
    vbCrLf & _
    "Hata No: " & Err.Number & _
    vbCrLf & _
    "A��klama: " & Err.Description

Set SAP_SESSION_AL = Nothing

End Function

'==========================================================
' BEL�RL� B�R SAP S�STEM� A�IK MI?
'
' �rnek:
' SAP_SISTEM_ACIK_MI("CDP")
' SAP_SISTEM_ACIK_MI("EPP")
'==========================================================
Public Function SAP_SISTEM_ACIK_MI( _
ByVal HedefSistem As String) As Boolean

Dim SAPSession As Object
Dim hataMesaji As String

On Error GoTo Hata

Set SAPSession = _
    SAP_SESSION_AL(HedefSistem, hataMesaji)

SAP_SISTEM_ACIK_MI = _
    Not SAPSession Is Nothing

Exit Function

Hata:

SAP_SISTEM_ACIK_MI = False

End Function

'==========================================================
' HERHANG� B�R SAP BA�LANTISI VAR MI?
'==========================================================
Public Function SAP_BAGLANTI_VAR_MI() As Boolean

Dim SAPSession As Object
Dim hataMesaji As String

On Error GoTo Hata

Set SAPSession = _
    SAP_SESSION_AL("", hataMesaji)

SAP_BAGLANTI_VAR_MI = _
    Not SAPSession Is Nothing

Exit Function

Hata:

SAP_BAGLANTI_VAR_MI = False

End Function

'==========================================================
' SAP S�STEM TEST�
'
' HedefSistem:
' CDP veya EPP
'==========================================================
Public Sub SAP_SISTEM_TEST( _
ByVal HedefSistem As String)

Dim SAPSession As Object
Dim hataMesaji As String

Dim SistemAdi As String
Dim ClientNo As String
Dim Transaction As String

Dim GecenSure As Double

On Error GoTo Hata

HedefSistem = _
    UCase$(Trim$(HedefSistem))

If HedefSistem <> "CDP" And _
   HedefSistem <> "EPP" Then

    MsgBox _
        "Ge�ersiz SAP sistem ad�." & _
        vbCrLf & vbCrLf & _
        "Ge�erli de�erler: CDP veya EPP", _
        vbExclamation, _
        "AKSORA"

    Exit Sub

End If

CORE_ISLEM_BASLAT _
    HedefSistem & " SAP ba�lant� kontrol�"

CORE_DURUM _
    HedefSistem & _
    " SAP oturumu aran�yor..."

Set SAPSession = _
    SAP_SESSION_AL(HedefSistem, hataMesaji)

If SAPSession Is Nothing Then

    GecenSure = CORE_ISLEM_BITIR()

    MsgBox _
        HedefSistem & _
        " SAP ba�lant�s� bulunamad�." & _
        vbCrLf & vbCrLf & _
        hataMesaji, _
        vbExclamation, _
        "AKSORA - SAP"

    Exit Sub

End If

SistemAdi = vbNullString
ClientNo = vbNullString
Transaction = vbNullString

On Error Resume Next

SistemAdi = _
    CStr(SAPSession.Info.SystemName)

ClientNo = _
    CStr(SAPSession.Info.Client)

Transaction = _
    CStr(SAPSession.Info.Transaction)

On Error GoTo Hata

GecenSure = CORE_ISLEM_BITIR()

MsgBox _
    HedefSistem & _
    " SAP ba�lant�s� ba�ar�yla bulundu." & _
    vbCrLf & vbCrLf & _
    "Sistem     : " & SistemAdi & vbCrLf & _
    "Client     : " & ClientNo & vbCrLf & _
    "��lem      : " & Transaction & vbCrLf & _
    "Kontrol    : " & _
    AKSORA_SAYI_METNI(GecenSure, "0.00") & " sn", _
    vbInformation, _
    "AKSORA - " & HedefSistem

Exit Sub

Hata:

hataMesaji = Err.Description

GecenSure = CORE_ISLEM_BITIR()

MsgBox _
    HedefSistem & _
    " SAP ba�lant� testi s�ras�nda hata olu�tu." & _
    vbCrLf & vbCrLf & _
    "Hata No: " & Err.Number & _
    vbCrLf & _
    "A��klama: " & hataMesaji, _
    vbCritical, _
    "AKSORA"

End Sub

'==========================================================
' CDP TEST
'
' Alt + F8 listesinde g�r�nmesi i�in parametresiz
' test prosed�r�.
'==========================================================
Public Function SAP_DURUM_METNI( _
ByVal HedefSistem As String) As String

If SAP_SISTEM_ACIK_MI(HedefSistem) Then

    SAP_DURUM_METNI = _
        UCase$(Trim$(HedefSistem)) & " BA�LI"

Else

    SAP_DURUM_METNI = _
        UCase$(Trim$(HedefSistem)) & " BA�LI DE��L"

End If

End Function


Public Function AKSORA_SAP_BLOK_BOYU(ByVal alv As Object) As Long
    Dim gorunen As Long
    AKSORA_SAP_BLOK_BOYU = 30
    On Error GoTo Cikis
    gorunen = CLng(alv.VisibleRowCount)
    If gorunen < 1 Then Exit Function
    If gorunen > 60 Then gorunen = 60
    AKSORA_SAP_BLOK_BOYU = gorunen
Cikis:
End Function

Public Sub AKSORA_SAP_OLCUM_KAYDET(ByVal il As String, ByVal adim As Long, _
    ByVal satir As Long, ByVal ToplamSure As Double, ByVal kontrolSure As Double)
    On Error Resume Next
    If mSAPDetay Is Nothing Then Set mSAPDetay = CreateObject("Scripting.Dictionary")
    mSAPDetay(il & "|" & CStr(adim)) = Array(satir, ToplamSure, kontrolSure)
    On Error GoTo 0
End Sub

Public Sub AKSORA_SAP_HIZ_OLC()
    If AKSORA_V11_MESGUL Or AKSORA_V13_GECIS Or AKSORA_V13_ACILIS Then Exit Sub
    Set mSAPDetay = CreateObject("Scripting.Dictionary")
    AKSORA_BUTUN_ILLERI_GUNCELLE
    AKSORA_SAP_HIZ_RAPORU
End Sub

Public Sub AKSORA_SAP_HIZ_RAPORU()
    Dim il As Variant, etiket As Variant, veri As Variant, adim As Long
    Dim n As Long, adet As Long, sure As Double, kontrol As Double, metin As String
    If mSAPDetay Is Nothing Then
        MsgBox "�nce AKSORA_SAP_HIZ_OLC komutuyla �l��ml� g�ncelleme yap�n.", vbInformation, "AKSORA | SAP �l��m�"
        Exit Sub
    End If
    If mSAPDetay.Count = 0 Then
        MsgBox "�l��len ba�ar�l� SAP ad�m� yok. G�ncelleme iptal edilmi� veya ba�ar�s�z olmu� olabilir.", vbInformation, "AKSORA | SAP �l��m�"
        Exit Sub
    End If
    etiket = Array("Normal CDP", "Normal EPP", "�l�e CDP", "�l�e EPP", "Y�klenici CDP", "Y�klenici EPP")
    metin = "Ba�ar�l� ad�mlar�n toplam� (5 il):" & vbCrLf
    Debug.Print "�L | ADIM | SATIR | SAP OKUYUCU sn | EK VER� KONTROL� sn"
    For adim = 1 To 6
        n = 0: adet = 0: sure = 0: kontrol = 0
        For Each il In Array("ARTVIN", "RIZE", "TRABZON", "GUMUSHANE", "GIRESUN")
            If mSAPDetay.Exists(CStr(il) & "|" & CStr(adim)) Then
                veri = mSAPDetay(CStr(il) & "|" & CStr(adim))
                n = n + CLng(veri(0)): sure = sure + CDbl(veri(1))
                kontrol = kontrol + CDbl(veri(2)): adet = adet + 1
                Debug.Print CStr(il) & " | " & CStr(etiket(adim - 1)) & " | " & veri(0) & _
                    " | " & AKSORA_SAYI_METNI(veri(1), "0.000") & " | " & AKSORA_SAYI_METNI(veri(2), "0.000")
            End If
        Next il
        metin = metin & vbCrLf & CStr(etiket(adim - 1)) & ": " & AKSORA_SAYI_METNI(sure, "0.1") & _
            " sn / " & AKSORA_SAYI_METNI(n, "#,##0") & " sat�r (" & adet & "/5)"
    Next adim
    metin = metin & vbCrLf & vbCrLf & "Ayr�nt�lar Ctrl+G penceresinde. Eksik ad�mlar toplama dahil de�il."
    MsgBox metin, vbInformation, "AKSORA | SAP Ad�m S�releri"
End Sub

