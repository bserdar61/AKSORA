Attribute VB_Name = "modAKSORA_MUSTERI_SAP"
Option Explicit

'==========================================================
' AKSORA - MUSTERI SAP (7155)  | Surum: MB52'siz, fiyat listeli
' Sorgu 1: ZMMRMC001 -> CDP (E001-E999,D003,D005,S001,Z002,Z003,Z007,EM14) + Yuklenici (M132)
' Sorgu 2: ZMMRMC001 -> Ilce (K001-K999 + 3 mal grubu)
' Deger = Miktar x Birim fiyat (modAKSORA_MUSTERI_FIYAT, Malzeme+Parti)
'==========================================================

#If VBA7 Then
Private Declare PtrSafe Sub MS_Sleep Lib "kernel32" Alias "Sleep" (ByVal ms As Long)
#Else
Private Declare Sub MS_Sleep Lib "kernel32" Alias "Sleep" (ByVal ms As Long)
#End If
Private mCalisiyor As Boolean
Private mBas As Double
Private mDurum As String
Private mFiyatTur As Boolean

Private Function MS_Gecen(ByVal bas As Double) As Double
    MS_Gecen = Timer - bas
    If MS_Gecen < 0 Then MS_Gecen = MS_Gecen + 86400#
End Function

Private Sub MS_Durum(ByVal metin As String)
    mDurum = metin
    application.StatusBar = "AKSORA | M��teri | " & metin
    DoEvents
End Sub

Private Sub MS_Bekle(ByVal ses As Object)
    Dim bas As Double
    bas = Timer
    Do While ses.Busy
        If MS_Gecen(bas) > 900 Then Err.Raise vbObjectError + 1900, , "SAP 15 dakika i�inde yan�t vermedi."
        DoEvents: MS_Sleep 50
    Loop
    If ses.FindById("wnd[0]/sbar").MessageType = "E" Then _
        Err.Raise vbObjectError + 1901, , ses.FindById("wnd[0]/sbar").Text
End Sub









Private Function MS_Norm(ByVal v As Variant) As String
    Dim t As String
    If IsError(v) Then Exit Function
    t = AKFIX_NORMAL(Trim$(CStr(v)))
    t = Replace(t, " ", ""): t = Replace(t, ".", ""): t = Replace(t, "/", "")
    t = Replace(t, "(", ""): t = Replace(t, ")", ""): t = Replace(t, "-", "")
    MS_Norm = t
End Function

Private Function MS_Alan(ByVal baslik As String, ByVal fiyat As Boolean) As Long
    Select Case baslik
        Case "UY", "URETIMYERI", "WERKS": MS_Alan = 1
        Case "DPYR", "DEPOYERI", "LGORT", "DEPO": MS_Alan = 2
        Case "DEPOFIKTI", "DEPOFIKTIFGUMRUKTANIMI", "DEPOYERITANIMI", "DEPOTANIMI", "LGOBE": MS_Alan = 3
        Case "MALGRUBU", "MATKL": MS_Alan = 4
        Case "MALZEME", "MATNR": MS_Alan = 5
        Case "MALZEMEKISAMETNI", "MALZEMEACIKLAMASI", "TANIM", "MAKTX": MS_Alan = 6
        Case "MIKTAR", "MIKT", "MENGE", "TAHDITSIZ", "LABST": MS_Alan = 7
        Case "TOB", "TEMELOLCUBIRIMI", "BIRIM", "MEINS": MS_Alan = 8
        Case "DEGERLEMETURU", "DEGERLTURU", "BWTAR": MS_Alan = 9
        Case "SERINUMARASI", "SERINUM", "SERINO", "SERNR": MS_Alan = 10
        Case "DEGER", "DEGERTL", "STOKDEGERI", "TOPLAMSTOKDEGERI", "SALK3": MS_Alan = 11
    End Select
End Function



Private Function MS_Sayi(ByVal v As Variant) As Double
    Dim t As String, re As Object
    If IsError(v) Or IsEmpty(v) Then Err.Raise vbObjectError + 1905, , "Bo� veya hatal� miktar/de�er h�cresi."
    If VarType(v) <> vbString And IsNumeric(v) Then MS_Sayi = CDbl(v): Exit Function
    t = Trim$(CStr(v)): t = Replace(t, ChrW(160), ""): t = Replace(t, " ", "")
    Set re = CreateObject("VBScript.RegExp")
    re.Pattern = "^-?[0-9]{1,3}([.][0-9]{3})+$"
    If InStr(t, ",") = 0 And re.Test(t) Then t = Replace(t, ".", "")
    If Right$(t, 1) = "-" Then t = "-" & Left$(t, Len(t) - 1)
    If InStr(t, ",") > 0 Then
        If InStrRev(t, ".") > InStrRev(t, ",") Then
            t = Replace(t, ",", "")
        Else
            t = Replace(Replace(t, ".", ""), ",", ".")
        End If
    End If
    Set re = CreateObject("VBScript.RegExp"): re.Pattern = "^-?[0-9]+([.][0-9]+)?$"
    If Not re.Test(t) Then Err.Raise vbObjectError + 1906, , "Say�sal alan okunamad�: " & CStr(v)
    MS_Sayi = Val(t)
End Function



Private Sub MS_Coklu(ByVal ses As Object, ByVal alan As String, ByVal degerler As Variant, ByVal ilk As String, ByVal son As String)
    Dim sil As Object, ip As String, sp As String, tip As String
    Dim visS As Long, visI As Long, nv As Long, i As Long, satirNo As Long, deger As String
    ses.FindById("wnd[0]/usr/btn%_" & alan & "_%_APP_%-VALU_PUSH").Press
    Set sil = ses.FindById("wnd[1]/tbar[0]/btn[16]", False)
    If sil Is Nothing Then Err.Raise vbObjectError + 1913, , "SAP �oklu se�im temizleme d��mesi bulunamad�."
    tip = AKFIX_NORMAL(sil.Tooltip)
    If InStr(tip, "DELETE") = 0 And InStr(tip, "SIL") = 0 Then _
        Err.Raise vbObjectError + 1914, , "SAP �oklu se�im temizleme d��mesi do�rulanamad�: " & sil.Tooltip
    sil.Press
    sp = "wnd[1]/usr/tabsTAB_STRIP/tabpSIVA/ssubSCREEN_HEADER:SAPLALDB:3010/tblSAPLALDBSINGLE/"
    ip = "wnd[1]/usr/tabsTAB_STRIP/tabpINTL/ssubSCREEN_HEADER:SAPLALDB:3020/tblSAPLALDBINTERVAL/"
    ses.FindById("wnd[1]/usr/tabsTAB_STRIP/tabpSIVA").Select
    visS = CLng(ses.FindById(Left$(sp, Len(sp) - 1)).VisibleRowCount)
    If IsArray(degerler) Then
        nv = UBound(degerler) - LBound(degerler) + 1
        For i = 0 To nv - 1
            If i < visS Then _
                ses.FindById(sp & "ctxtRSCSEL_255-SLOW_I[1," & CStr(i) & "]").Text = CStr(degerler(LBound(degerler) + i))
        Next i
    End If
    If Len(ilk) > 0 Or nv > visS Then
        ses.FindById("wnd[1]/usr/tabsTAB_STRIP/tabpINTL").Select
        visI = CLng(ses.FindById(Left$(ip, Len(ip) - 1)).VisibleRowCount)
        satirNo = 0
        If Len(ilk) > 0 Then
            ses.FindById(ip & "ctxtRSCSEL_255-ILOW_I[1,0]").Text = ilk
            ses.FindById(ip & "ctxtRSCSEL_255-IHIGH_I[2,0]").Text = son
            satirNo = 1
        End If
        ' Tek de�er tablosuna s��mayan de�erler "X - X" aral��� olarak yaz�l�r.
        For i = visS To nv - 1
            If satirNo >= visI Then Err.Raise vbObjectError + 1920, , "SAP �oklu se�im penceresine s��mayan de�erler var (" & alan & ")."
            deger = CStr(degerler(LBound(degerler) + i))
            ses.FindById(ip & "ctxtRSCSEL_255-ILOW_I[1," & CStr(satirNo) & "]").Text = deger
            ses.FindById(ip & "ctxtRSCSEL_255-IHIGH_I[2," & CStr(satirNo) & "]").Text = deger
            satirNo = satirNo + 1
        Next i
    End If
    ses.FindById("wnd[1]/tbar[0]/btn[8]").Press
End Sub

Private Sub MS_Duzen(ByVal ses As Object, ByVal musteri As Boolean)
    Dim alv As Object, grid As Object, yol As String, r As Long, ad As String, secim As Long
    If musteri Then
        Set alv = ses.FindById("wnd[0]/usr/cntlGRID1/shellcont/shell")
        alv.SetCurrentCell -1, "MAKTX": alv.SelectColumn "MAKTX"
        alv.ContextMenu: alv.SelectContextMenuItem "&COL0"
        ses.FindById("wnd[1]/tbar[0]/btn[36]").Press
        yol = "wnd[1]/usr/tabsG_TS_ALV/tabpALV_M_R9/ssubSUB_CONFIGURATION:SAPLSALV_CUL_LAYOUT_CHOOSE:0500/cntlD500_CONTAINER/shellcont/shell"
    Else
        ses.FindById("wnd[0]/tbar[1]/btn[33]").Press
        yol = "wnd[1]/usr/subSUB_CONFIGURATION:SAPLSALV_CUL_LAYOUT_CHOOSE:0500/cntlD500_CONTAINER/shellcont/shell"
    End If
    Set grid = ses.FindById(yol): secim = -1
    For r = 0 To CLng(grid.RowCount) - 1
        ad = Trim$(CStr(grid.GetCellValue(r, "VARIANT")))
        If (musteri And ad = "/PANEL") Or (Not musteri And (ad = "PANEL" Or ad = "/PANEL")) Then secim = r: Exit For
    Next r
    If secim < 0 Then Err.Raise vbObjectError + 1915, , "SAP'de beklenen PANEL d�zeni bulunamad�."
    grid.SetCurrentCell secim, "TEXT": grid.SelectedRows = CStr(secim): grid.ClickCurrentCell
    If musteri Then ses.FindById("wnd[1]/tbar[0]/btn[0]").Press
End Sub

Private Function MS_Sorgu(ByVal ses As Object, ByVal ikinci As Boolean) As Variant
    Dim kutu As Variant, bos As Variant
    ses.StartTransaction "ZMMRMC001": MS_Bekle ses
    For Each kutu In Array("P_FIKTIF", "P_FIKSTT", "P_MUSSIP", "P_MUSSTK", "P_SATFAS")
        ses.FindById("wnd[0]/usr/chk" & CStr(kutu)).Selected = False
    Next kutu
    ses.FindById("wnd[0]/usr/ctxtS_WERKS-LOW").Text = "7155"
    If ikinci Then
        ' �l�e depolar�: K001-K999 ve �� mal grubu
        MS_Coklu ses, "S_LGORT", bos, "K001", "K999"
        MS_Coklu ses, "S_MATKL", Array("M03550000", "M03550100", "M03250000"), "", ""
    Else
        ' CDP: E001-E999, D003, D005, S001, Z002, Z003, Z007, EM14  |  Y�klenici: M132
        MS_Coklu ses, "S_LGORT", Array("D003", "D005", "S001", "Z002", "Z003", "Z007", "EM14", "M132"), "E001", "E999"
        MS_Coklu ses, "S_MATKL", bos, "", ""
    End If
    ses.FindById("wnd[0]/tbar[1]/btn[8]").Press: MS_Bekle ses
    MS_Duzen ses, True
    MS_Sorgu = MS_ALV_Oku(ses, False)
End Function

Private Function MS_Malzeme(ByVal v As Variant) As String
    Dim t As String, re As Object
    t = Trim$(CStr(v))
    Set re = CreateObject("VBScript.RegExp"): re.Pattern = "^[0-9]+$"
    If re.Test(t) Then
        Do While Len(t) > 1 And Left$(t, 1) = "0": t = Mid$(t, 2): Loop
    End If
    MS_Malzeme = UCase$(t)
End Function

'==========================================================
' DEPO -> SAYFA ESLEMESI
' 1 = M_CDP_STOK       : E001-E999, D003, D005, S001, Z002, Z003, Z007, EM14
' 2 = M_ILCE_STOK      : K001-K999
' 3 = M_YUKLENICI_STOK : M132
' 0 = taninmayan depo
'==========================================================
Private Function MS_Hedef(ByVal depo As String) As Long
    Dim n As Long
    depo = UCase$(Trim$(depo))
    Select Case depo
        Case "D003", "D005", "S001", "Z002", "Z003", "Z007", "EM14": MS_Hedef = 1: Exit Function
        Case "M132": MS_Hedef = 3: Exit Function
    End Select
    If Len(depo) = 4 Then
        If Mid$(depo, 2) Like "###" Then
            n = CLng(Mid$(depo, 2))
            If n >= 1 Then
                If Left$(depo, 1) = "E" Then MS_Hedef = 1
                If Left$(depo, 1) = "K" Then MS_Hedef = 2
            End If
        End If
    End If
End Function

Private Sub MS_KapsamKontrol(ByRef a As Variant, ByVal izin1 As Long, ByVal izin2 As Long, ByVal grupSart As Boolean)
    Dim r As Long, h As Long, g As String
    For r = 1 To UBound(a, 1)
        h = MS_Hedef(CStr(a(r, 2)))
        If h = 0 Or (h <> izin1 And h <> izin2) Then _
            Err.Raise vbObjectError + 1916, , "SAP ��kt�s�nda sorgu kapsam� d���nda depo var: " & CStr(a(r, 2))
        If grupSart Then
            g = UCase$(CStr(a(r, 4)))
            If g <> "M03550000" And g <> "M03550100" And g <> "M03250000" Then _
                Err.Raise vbObjectError + 1916, , "SAP ��kt�s�nda sorgu kapsam� d���nda mal grubu var: " & CStr(a(r, 2)) & " / " & g
        End If
    Next r
End Sub

Private Sub MS_SeriKontrol(ByRef a As Variant)
    Dim seri As Object, r As Long, sk As String
    Set seri = CreateObject("Scripting.Dictionary")
    For r = 1 To UBound(a, 1)
        If Len(CStr(a(r, 10))) > 0 Then
            sk = MS_Malzeme(a(r, 5)) & "|" & CStr(a(r, 10))
            If seri.Exists(sk) Then Err.Raise vbObjectError + 1917, , "Ayn� malzeme/seri numaras� birden fazla sat�rda: " & sk
            seri(sk) = True
        End If
    Next r
End Sub

' Fiyat listesinden (Malzeme + Parti) birim fiyat uygular. Fiyatsiz kalan satir sayisini dondurur.
Private Function MS_FiyatUygula(ByRef a As Variant, ByVal d As Object, ByVal tarihMetni As String) As Long
    Dim r As Long, k As String, v As Variant, eksik As Long
    For r = 1 To UBound(a, 1)
        k = MF_Anahtar(a(r, 5), a(r, 9))
        a(r, 11) = vbNullString: a(r, 12) = vbNullString: a(r, 14) = 1
        If d.Exists(k) Then
            v = d(k)
            If CStr(v(1)) = "TEK" Then
                a(r, 12) = CDbl(v(0))
                a(r, 11) = CDec(a(r, 7)) * CDec(v(0))
                a(r, 13) = "Fiyat listesi (" & tarihMetni & ")"
                a(r, 14) = 0
            ElseIf CStr(v(1)) = "BELIRSIZ" Then
                a(r, 13) = "Fiyat belirsiz (listede �eli�kili)"
            Else
                a(r, 13) = "Listede fiyat 0"
            End If
        Else
            a(r, 13) = "Fiyat listede yok"
        End If
        If CLng(a(r, 14)) > 0 Then eksik = eksik + 1
    Next r
    MS_FiyatUygula = eksik
End Function

Private Function MS_Ayir(ByRef a As Variant, ByVal hedef As Long) As Variant
    Dim r As Long, c As Long, n As Long, k As Long, sonuc() As Variant
    For r = 1 To UBound(a, 1)
        If MS_Hedef(CStr(a(r, 2))) = hedef Then n = n + 1
    Next r
    If n = 0 Then Exit Function
    ReDim sonuc(1 To n, 1 To 14)
    For r = 1 To UBound(a, 1)
        If MS_Hedef(CStr(a(r, 2))) = hedef Then
            k = k + 1
            For c = 1 To 14: sonuc(k, c) = a(r, c): Next c
        End If
    Next r
    MS_Ayir = sonuc
End Function

Private Sub MS_SeriBirlesimKontrol(ByRef bir As Variant, ByRef iki As Variant)
    Dim d As Object, r As Long, k As String
    Set d = CreateObject("Scripting.Dictionary")
    For r = 1 To UBound(bir, 1)
        If Len(CStr(bir(r, 10))) > 0 Then d(MS_Malzeme(bir(r, 5)) & "|" & CStr(bir(r, 10))) = True
    Next r
    For r = 1 To UBound(iki, 1)
        If Len(CStr(iki(r, 10))) > 0 Then
            k = MS_Malzeme(iki(r, 5)) & "|" & CStr(iki(r, 10))
            If d.Exists(k) Then Err.Raise vbObjectError + 1919, , "�ki sorguda ayn� malzeme/seri bulundu. ��lem s�ras�nda depo hareketi olmu� olabilir: " & k
        End If
    Next r
End Sub

Public Sub AKSORA_MUSTERI_SAP_BAGLA(ByVal ws As Worksheet)
    Dim s As Shape, adlar As Variant, ad As Variant
    Select Case ws.Name
        Case "M_CDP_STOK": adlar = Array("SAP_STOK_GUNCELLE_BTN")
        Case "M_�L�E_STOK": adlar = Array("CDP_ILCE_STOK_BTN")
        Case "M_Y�KLEN�C�_STOK": adlar = Array("YUK_EDAS_GUNCELLE_BTN")
        Case "M_ANA PANEL": adlar = Array("btnCDP", "btnIlce", "btnYuk")
        Case Else: Exit Sub
    End Select
    For Each ad In adlar
        Set s = Nothing
        On Error Resume Next
        Set s = ws.Shapes(CStr(ad))
        On Error GoTo 0
        If Not s Is Nothing Then s.OnAction = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!AKSORA_MUSTERI_7155_GUNCELLE"
    Next ad
End Sub

Private Sub MS_Yaz(ByVal ws As Worksheet, ByRef a As Variant)
    Dim son As Long, n As Long, s As Shape
    If IsEmpty(a) Then n = 0 Else n = UBound(a, 1)
    son = application.Max(7, ws.Cells(ws.Rows.Count, "E").End(xlUp).Row)
    ws.Unprotect ""
    If ws.FilterMode Then ws.ShowAllData
    ws.AutoFilterMode = False
    ws.Range("A7:N" & application.Max(son, n + 6)).ClearContents
    If n > 0 Then
        ws.Range("A7:F" & n + 6).NumberFormat = "@"
        ws.Range("H7:J" & n + 6).NumberFormat = "@"
        ws.Range("A7").Resize(n, 14).Value2 = a
    End If
    ws.Range("K6:N6").Value = Array("De�er (TL)", "Birim stok de�eri (TL)", "Fiyat durumu", "Fiyat eksik")
    ws.Columns("K:N").Hidden = True
    ws.Range("C2").Value = Now: ws.Range("C2").NumberFormat = "dd.mm.yyyy hh:mm:ss"
    For Each s In ws.Shapes
        If InStr(s.Name, "STOK_KPI_ETIKET_2") > 0 Then s.TextFrame2.TextRange.Text = "Toplam Stok De�eri"
    Next s
    AKSORA_MUSTERI_SAYFA_HAZIRLA ws
    ws.Protect Password:="", DrawingObjects:=True, Contents:=True, UserInterfaceOnly:=True, AllowFiltering:=True
End Sub

Public Sub AKSORA_MUSTERI_7155_GUNCELLE()
    Dim ses As Object, hMesaj As String, bir As Variant, iki As Variant, d As Object
    Dim sayfa(1 To 3) As Worksheet, yeni(1 To 3) As Variant, eski(1 To 3) As Variant
    Dim tarihEski(1 To 3) As Variant, sonEski(1 To 3) As Long
    Dim ev As Boolean, sc As Boolean, hesap As XlCalculation, yazildi As Boolean
    Dim i As Long, nn As Long, tarih As Date, adlar As Variant, eksik As Long, adet(1 To 3) As Long
    If mCalisiyor Or AKSORA_V11_MESGUL Then Exit Sub
    If CStr(ThisWorkbook.Worksheets("MUSTERI IL SECIM").Range("AZ1").Value2) <> "ARTVIN" Then
        MsgBox "Bu aktar�m yaln�zca 7155 / Artvin i�in haz�rlanm��t�r.", vbExclamation, "AKSORA": Exit Sub
    End If
    mCalisiyor = True: mBas = Timer
    ev = application.EnableEvents: sc = application.ScreenUpdating: hesap = application.Calculation
    On Error GoTo Hata
    ' Fiyat listesi SAP'a gitmeden �nce do�rulan�r.
    Set d = MF_FIYAT_SOZLUGU(tarih, hMesaj)
    If d Is Nothing Then Err.Raise vbObjectError + 1930, , hMesaj
    Set ses = SAP_SESSION_AL("CDP", hMesaj)
    If ses Is Nothing Then Err.Raise vbObjectError + 1918, , hMesaj
    adlar = Array("M_CDP_STOK", "M_�L�E_STOK", "M_Y�KLEN�C�_STOK")
    For i = 1 To 3
        Set sayfa(i) = ThisWorkbook.Worksheets(CStr(adlar(i - 1)))
    Next i
    application.EnableEvents = False: application.Calculation = xlCalculationManual
    AKSORA_V11_MESGUL = True
    MS_Durum "1/2 | CDP + Y�klenici depolar� (E001-E999, D/Z/S/EM, M132)..."
    bir = MS_Sorgu(ses, False)
    MS_Durum "2/2 | �l�e depolar� K001-K999 ve �� mal grubu..."
    iki = MS_Sorgu(ses, True)
    MS_KapsamKontrol bir, 1, 3, False
    MS_KapsamKontrol iki, 2, 2, True
    MS_SeriKontrol bir: MS_SeriKontrol iki
    MS_SeriBirlesimKontrol bir, iki
    mFiyatTur = True
    MS_Durum "Fiyat listesi uygulan�yor..."
    eksik = MS_FiyatUygula(bir, d, Format$(tarih, "dd.mm.yyyy"))
    eksik = eksik + MS_FiyatUygula(iki, d, Format$(tarih, "dd.mm.yyyy"))
    yeni(1) = MS_Ayir(bir, 1): yeni(2) = iki: yeni(3) = MS_Ayir(bir, 3)
    For i = 1 To 3
        sonEski(i) = application.Max(7, sayfa(i).Cells(sayfa(i).Rows.Count, "E").End(xlUp).Row)
        eski(i) = sayfa(i).Range("A7:N" & sonEski(i)).Value2
        tarihEski(i) = sayfa(i).Range("C2").Value
        If IsEmpty(yeni(i)) Then adet(i) = 0 Else adet(i) = UBound(yeni(i), 1)
    Next i
    yazildi = True
    For i = 1 To 3: MS_Yaz sayfa(i), yeni(i): Next i
    yazildi = False
    MS_Durum "Tamamland� | CDP " & adet(1) & " | �l�e " & adet(2) & " | Y�klenici " & adet(3) & _
        " | Fiyat� olmayan " & eksik & " | " & AKSORA_SAYI_METNI(MS_Gecen(mBas), "0.00") & " sn"
    ThisWorkbook.names.Add Name:="_AKSORA_MUSTERI_7155_SON_SURE", RefersTo:="=" & Trim$(Str$(Round(MS_Gecen(mBas), 2))), Visible:=False
    MsgBox "M��teri 7155 g�ncellendi." & vbCrLf & vbCrLf & _
        "CDP stok sat�r�: " & AKSORA_SAYI_METNI(adet(1), "#,##0") & vbCrLf & _
        "�l�e stok sat�r�: " & AKSORA_SAYI_METNI(adet(2), "#,##0") & vbCrLf & _
        "Y�klenici stok sat�r�: " & AKSORA_SAYI_METNI(adet(3), "#,##0") & vbCrLf & vbCrLf & _
        "Fiyat� bulunamayan/belirsiz sat�r: " & AKSORA_SAYI_METNI(eksik, "#,##0") & vbCrLf & _
        "Fiyat listesi tarihi: " & Format$(tarih, "dd.mm.yyyy hh:nn") & vbCrLf & _
        "S�re: " & AKSORA_SAYI_METNI(MS_Gecen(mBas), "0.00") & " sn", vbInformation, "AKSORA | M��teri 7155"
Cikis:
    application.Calculation = hesap: application.EnableEvents = ev: application.ScreenUpdating = sc
    application.StatusBar = False: AKSORA_V11_MESGUL = False: mCalisiyor = False
    Exit Sub
Hata:
    hMesaj = mDurum & vbCrLf & "Hata " & CStr(Err.Number) & ": " & Err.Description
    If yazildi Then
        On Error Resume Next
        Err.Clear
        For i = 1 To 3
            If IsEmpty(yeni(i)) Then nn = 0 Else nn = UBound(yeni(i), 1)
            sayfa(i).Unprotect ""
            sayfa(i).Range("A7:N" & application.Max(sonEski(i), nn + 6)).ClearContents
            sayfa(i).Range("A7").Resize(UBound(eski(i), 1), 14).Value2 = eski(i)
            sayfa(i).Range("C2").Value = tarihEski(i)
            sayfa(i).Protect Password:="", DrawingObjects:=True, Contents:=True, UserInterfaceOnly:=True, AllowFiltering:=True
        Next i
        If Err.Number <> 0 Then hMesaj = hMesaj & vbCrLf & "Eski kay�tlar�n geri y�klenmesi do�rulanamad�: " & Err.Description
        On Error GoTo 0
    End If
    MsgBox "Aktar�m tamamlanamad�: " & hMesaj, vbExclamation, "AKSORA"
    Resume Cikis
End Sub

Private Function MS_ALV_Oku(ByVal ses As Object, ByVal fiyat As Boolean) As Variant
    Dim alv As Object, kolonlar As Object, basliklar As Object, ids(1 To 11) As String
    Dim id As String, no As Long, i As Long, j As Long, k As Long, c As Long
    Dim n As Long, adet As Long, blok As Long, bas As Long, bitis As Long, r As Long
    Dim buf() As Variant, sonuc() As Variant, satir(1 To 14) As Variant
    Dim zorunlu As Variant, x As Variant, tekrar As Long, hataNo As Long, hataMetni As String
    Dim tamam As Boolean, ozet As Boolean, asama As String, ilk As Long
    Set alv = ses.FindById("wnd[0]/usr/cntlGRID1/shellcont/shell")
    On Error Resume Next
    alv.PressToolbarButton "&DELETE_FILTER"
    On Error GoTo 0
    Set kolonlar = alv.ColumnOrder
    For i = 0 To CLng(kolonlar.Count) - 1
        id = CStr(kolonlar.Item(i))
        no = MS_Alan(MS_Norm(id), fiyat)
        If no = 0 Then
            Set basliklar = alv.GetColumnTitles(id)
            For j = 0 To CLng(basliklar.Count) - 1
                no = MS_Alan(MS_Norm(CStr(basliklar.Item(j))), fiyat)
                If no > 0 Then Exit For
            Next j
        End If
        If no > 0 Then
            If Len(ids(no)) > 0 And ids(no) <> id Then _
                Err.Raise vbObjectError + 1922, , "ALV'de ayn� alana uyan birden fazla s�tun var: " & ids(no) & "/" & id
            ids(no) = id
        End If
    Next i
    If fiyat Then zorunlu = Array(1, 2, 5, 7, 8, 11) Else zorunlu = Array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    For Each x In zorunlu
        If Len(ids(CLng(x))) = 0 Then Err.Raise vbObjectError + 1923, , "ALV d�zeninde gerekli alan bulunamad�: " & CStr(x)
    Next x
    If fiyat Then mFiyatTur = (Len(ids(9)) > 0)
    n = CLng(alv.RowCount)
    If n < 1 Or n > 250000 Then Err.Raise vbObjectError + 1924, , "ALV stok sat�r say�s� ge�ersiz: " & CStr(n)
    blok = application.Min(30, CLng(alv.VisibleRowCount))
    If blok < 1 Then Err.Raise vbObjectError + 1925, , "ALV g�r�n�r sat�r say�s� okunamad�."
    ReDim buf(1 To n, 1 To 14)
    asama = mDurum
    For bas = 0 To n - 1 Step blok
        alv.FirstVisibleRow = application.Min(bas, application.Max(0, n - CLng(alv.VisibleRowCount)))
        DoEvents: MS_Sleep 15
        bitis = application.Min(n - 1, bas + blok - 1)
        If CLng(alv.RowCount) <> n Then Err.Raise vbObjectError + 1926, , "Okuma s�ras�nda SAP sat�r say�s� de�i�ti; aktar�m durduruldu."
        For r = bas To bitis
            tamam = False
            For tekrar = 0 To 2
                For c = 1 To 14: satir(c) = Empty: Next c
                hataNo = 0: hataMetni = ""
                On Error Resume Next
                If tekrar > 0 Then
                    alv.FirstVisibleRow = application.Min(r, application.Max(0, n - CLng(alv.VisibleRowCount)))
                    alv.SetCurrentCell r, ids(5)
                    DoEvents: MS_Sleep 30
                End If
                For c = 1 To 11
                    If Len(ids(c)) > 0 Then
                        Err.Clear
                        satir(c) = CStr(alv.GetCellValue(r, ids(c)))
                        If Err.Number <> 0 Then hataNo = Err.Number: hataMetni = Err.Description: Exit For
                    End If
                Next c
                On Error GoTo 0
                If hataNo = 0 Then
                    ozet = (Len(Trim$(CStr(satir(1)))) = 0 And Len(Trim$(CStr(satir(5)))) = 0)
                    If ozet Then
                        tamam = (Len(Trim$(CStr(satir(7)))) > 0 Or Len(Trim$(CStr(satir(11)))) > 0)
                    Else
                        tamam = (Trim$(CStr(satir(1))) = "7155" And Len(Trim$(CStr(satir(5)))) > 0)
                    End If
                End If
                If tamam Then Exit For
            Next tekrar
            If Not tamam Then Err.Raise vbObjectError + 1927, , "ALV sat�r� eksiksiz okunamad�: " & CStr(r + 1) & " / " & hataMetni
            If Not ozet Then
                adet = adet + 1
                For c = 1 To 11: buf(adet, c) = satir(c): Next c
                buf(adet, 7) = MS_Sayi(buf(adet, 7))
                If fiyat Then
                    If Len(Trim$(CStr(buf(adet, 11)))) > 0 Then buf(adet, 11) = MS_Sayi(buf(adet, 11))
                Else
                    buf(adet, 10) = CStr(satir(10))
                End If
                For Each x In Array(1, 2, 4, 5, 8, 9)
                    buf(adet, CLng(x)) = Trim$(CStr(buf(adet, CLng(x))))
                Next x
            End If
        Next r
        MS_Durum asama & " | ALV " & CStr(bitis + 1) & "/" & CStr(n)
    Next bas
    If adet = 0 Then Err.Raise vbObjectError + 1928, , "ALV'de stok kayd� bulunamad�."
    ReDim sonuc(1 To adet, 1 To 14)
    For r = 1 To adet
        For c = 1 To 14: sonuc(r, c) = buf(r, c): Next c
    Next r
    MS_ALV_Oku = sonuc
End Function
